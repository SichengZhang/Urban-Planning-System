/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.WorkQueue;

import Business.Data.DataPackage;

/**
 *
 * @author Sc Zhang
 */
public class WorkRequestCommon extends WorkRequest{
    
    private DataPackage dataPackage;

    public WorkRequestCommon(){
        super();
        dataPackage = new DataPackage();
    }
    
    public DataPackage getDataPackage() {
        return dataPackage;
    }

    public void setDataPackage(DataPackage dataPackage) {
        this.dataPackage = dataPackage;
    }
    
    
}
