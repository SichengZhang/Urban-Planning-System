/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Organization;

import Business.Data.HousingDataBase;
import Business.Data.PopulationDataBase;
import Business.UrbanCensusOrganization_Department.HousingDepartment;
import Business.UrbanCensusOrganization_Department.PopulationDepartment;

/**
 *
 * @author Sc Zhang
 */
public class UrbanCensusOrganization extends Organization{
    
    private HousingDataBase housingDataBase;
    private PopulationDataBase populationDataBase;
   

    public HousingDataBase getHousingDataBase() {
        return housingDataBase;
    }

    public void setHousingDataBase(HousingDataBase housingDataBase) {
        this.housingDataBase = housingDataBase;
    }

    public PopulationDataBase getPopulationDataBase() {
        return populationDataBase;
    }

    public void setPopulationDataBase(PopulationDataBase populationDataBase) {
        this.populationDataBase = populationDataBase;
    }
    
    
    
    public UrbanCensusOrganization(String name){
        super(OrganizationType.UrbanCensusOrganization, name);
        housingDataBase = new HousingDataBase();
        populationDataBase= new PopulationDataBase();
    }
}
