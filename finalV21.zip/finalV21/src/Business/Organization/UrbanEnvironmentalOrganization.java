/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Organization;

import Business.Data.AirDataBase;
import Business.Data.VegetationDataBase;
import Business.Data.WaterDataBase;
import Business.UrbanEnvironmentalOrganization_Department.AirQualityDepartment;
import Business.UrbanEnvironmentalOrganization_Department.VegetationDepartment;
import Business.UrbanEnvironmentalOrganization_Department.WaterQualityDepartment;

/**
 *
 * @author Sc Zhang
 */
public class UrbanEnvironmentalOrganization extends Organization{
    
    private AirDataBase airDataBase;
    private WaterDataBase waterDataBase;
    private VegetationDataBase vegetationDataBase;

    public AirDataBase getAirDataBase() {
        return airDataBase;
    }

    public void setAirDataBase(AirDataBase airDataBase) {
        this.airDataBase = airDataBase;
    }

    public WaterDataBase getWaterDataBase() {
        return waterDataBase;
    }

    public void setWaterDataBase(WaterDataBase waterDataBase) {
        this.waterDataBase = waterDataBase;
    }

    public VegetationDataBase getVegetationDataBase() {
        return vegetationDataBase;
    }

    public void setVegetationDataBase(VegetationDataBase vegetationDataBase) {
        this.vegetationDataBase = vegetationDataBase;
    }
            
            
    
    public UrbanEnvironmentalOrganization(String name){
        super(OrganizationType.UrbanEnvironmentalOrganization, name);
        airDataBase = new AirDataBase();
        waterDataBase = new WaterDataBase();
        vegetationDataBase = new VegetationDataBase();
        
    }
}
