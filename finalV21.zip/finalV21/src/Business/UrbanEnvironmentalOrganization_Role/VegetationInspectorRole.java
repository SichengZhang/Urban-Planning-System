/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.UrbanEnvironmentalOrganization_Role;

import Business.Role.Role;

/**
 *
 * @author Sc Zhang
 */
public class VegetationInspectorRole extends Role{
    
    public VegetationInspectorRole() {
        super(RoleType.VegetationQualityInspectorRole);
    }
    
}
