/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.UrbanPlanningOrganization_Department;

import Business.Department.Department;
import Business.Role.Role;
import Business.UrbanPlanningOrganization_Role.StrategicConsultantRole;

/**
 *
 * @author Sc Zhang
 */
public class StrategicPlanningDepartment extends Department{
    
    public StrategicPlanningDepartment(){
        super(DepartmentType.StrategicPlanningDepartment);
    }

    @Override
    public Role getSupportedRole() {
       return new StrategicConsultantRole();
    }

    @Override
    public String toString() {
        return super.getName();
    }
}
