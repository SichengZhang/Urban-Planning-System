/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.BasicMathematicMethods;

import java.util.ArrayList;
import java.util.Arrays;

/**
 *
 * @author zhangshu
 */
public class BasicMathematicMethods {
    
public double getMean(ArrayList<Double> list)
   {
       int i = 0;
       double sum = 0.0;
       double size = list.size()-1;
       for(i=0; i< list.size(); i++)
           sum += list.get(i);
       return sum/size;
   }

public double getVariance(ArrayList<Double> list)
   {
       int i = 0;
       double mean = getMean(list);
       double temp = 0;
       double size = list.size()-1;
       for(i=0; i <list.size(); i++)
           temp += (list.get(i)-mean)*(list.get(i)-mean);
       return temp/size;
   }

public double getStdDev(ArrayList<Double> list)
   {
       return Math.sqrt(getVariance(list));
   }

public double getIncrementalRatio(ArrayList<Double> list)
  {
       int size = list.size();
       double firstData = list.get(0);
       double lastData = list.get(size-1);
       double ratio = (lastData - firstData)/firstData;
       return ratio;
  }
   
}
    

