/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import Business.City.City;
import Business.Data.AirData;
import Business.Data.AirDataBase;
import Business.Data.HousingData;
import Business.Data.HousingDataBase;
import Business.Data.PopulationData;
import Business.Data.PopulationDataBase;
import Business.Data.RandomGenerator;
import Business.Data.VegetationData;
import Business.Data.VegetationDataBase;
import Business.Data.WaterData;
import Business.Data.WaterDataBase;
import Business.Department.Department;
import Business.Employee.Employee;
import Business.Organization.Organization;
import Business.Organization.UrbanCensusOrganization;
import Business.Organization.UrbanEnvironmentalOrganization;
import Business.Organization.UrbanPlanningOrganization;
import Business.Role.OrganizationAdminRole;
import Business.Role.Role;
import Business.Role.SystemAdminRole;
import Business.State.State;
import Business.UrbanCensusOrganization_Role.HousingManagerRole;
import Business.UrbanCensusOrganization_Role.PopulationInspectorRole;
import Business.UrbanEnvironmentalOrganization_Role.AirQualityInspectorRole;
import Business.UrbanEnvironmentalOrganization_Role.VegetationInspectorRole;
import Business.UrbanEnvironmentalOrganization_Role.WaterQualityInspectorRole;
import Business.UrbanPlanningOrganization_Role.DataAnalystRole;
import Business.UrbanPlanningOrganization_Role.StrategicConsultantRole;
import Business.UserAccount.UserAccount;

/**
 *
 * @author Sc Zhang
 */
public class Configuration {
    
    public static EcoSystem configure(){
        
        EcoSystem system = EcoSystem.getInstance();
        
        //Create a network
        //create an enterprise
        //initialize some organizations
        //have some employees 
        //create user account
        
        for (int i = 0; i <= 4; i++){
            State state = system.getStateDirectory().createAndAddState(RandomGenerator.getStateName());
            
            for (int j = 0; j <= 4; j++){
                state.getCityDirectory().createAndAddCity(RandomGenerator.getCityName());
                
            }
        }
        int a = 0;
        int b = 0;
        int c = 0;
      
        
        
        for (State state : system.getStateDirectory().getStateDirectory()) {
            for (City city : state.getCityDirectory().getCityDirectory()) {
                
                AirData oringnalAirData = RandomGenerator.initFirstAirData(5, 1983);
                WaterData oringnalWaterData = RandomGenerator.initFirstWaterData(5, 1983);
                VegetationData oringnalVegetationData = RandomGenerator.initFirstVegetationData(5, 1983);
                PopulationData oringnalPopulationData = RandomGenerator.initFirstPopulationrData(5, 1983);
                HousingData oringnalHousingData = RandomGenerator.initHousingData(5, 1983);

                
                System.out.println(oringnalWaterData + " orin");
                AirData currentAirData = oringnalAirData;
                AirData nextAirData;

                WaterData currentWaterData = oringnalWaterData;
                WaterData nextWaterData;

                VegetationData currentVegetationData = oringnalVegetationData;
                VegetationData nextVegetationData;

                PopulationData currentPopulationData = oringnalPopulationData;
                PopulationData nextPopulationData;

                HousingData currentHousingData = oringnalHousingData;
                HousingData nextHousingData;

                UrbanCensusOrganization urbanCensusOrganization = (UrbanCensusOrganization) city.getOrganizationDirectory().createAndAddOrganization("Urban Census Organization" + String.valueOf(a), Organization.OrganizationType.UrbanCensusOrganization);
                urbanCensusOrganization.getHousingDataBase().addNewHousingData(oringnalHousingData);
                urbanCensusOrganization.getPopulationDataBase().addNewPopulationData(oringnalPopulationData);

                Department housing = urbanCensusOrganization.getDepartmentDirectory().createAndAddDepartment("Housing Department", Department.DepartmentType.HousingDepartment);
                Employee housingInspector =housing.getPersonDirectory().createEmployee(RandomGenerator.getName());
                housing.getUserAccountDirectory().createUserAccount(housingInspector.getName(), housingInspector.getName(), housingInspector, new HousingManagerRole());
                
                Department population = urbanCensusOrganization.getDepartmentDirectory().createAndAddDepartment("Population Department", Department.DepartmentType.PopulationDepartment);
                Employee populationInspector =population.getPersonDirectory().createEmployee(RandomGenerator.getName());
                population.getUserAccountDirectory().createUserAccount(populationInspector.getName(), populationInspector.getName(), populationInspector, new PopulationInspectorRole());
                
                Employee ucAdmin = urbanCensusOrganization.getEmployeeDirectory().createEmployee(RandomGenerator.getName());
                urbanCensusOrganization.getUserAccountDirectory().createUserAccount(ucAdmin.getName(), ucAdmin.getName(), ucAdmin, new OrganizationAdminRole());
                
                UrbanEnvironmentalOrganization urbanEnvironmentalOrganization = (UrbanEnvironmentalOrganization) city.getOrganizationDirectory().createAndAddOrganization("Urban Environmental Organization" + String.valueOf(b), Organization.OrganizationType.UrbanEnvironmentalOrganization);
                urbanEnvironmentalOrganization.getAirDataBase().addNewAirData(oringnalAirData);
                urbanEnvironmentalOrganization.getWaterDataBase().addNewWaterData(oringnalWaterData);
                urbanEnvironmentalOrganization.getVegetationDataBase().addNewVegetationData(oringnalVegetationData);

                
                
                Department air = urbanEnvironmentalOrganization.getDepartmentDirectory().createAndAddDepartment("Air Quality Department", Department.DepartmentType.AirQualityDepartment);
                Employee airQualityInspector =air.getPersonDirectory().createEmployee(RandomGenerator.getName());
                air.getUserAccountDirectory().createUserAccount(airQualityInspector.getName(), airQualityInspector.getName(), airQualityInspector, new AirQualityInspectorRole());
                
                
                Department water = urbanEnvironmentalOrganization.getDepartmentDirectory().createAndAddDepartment("WaterQualityDepartment", Department.DepartmentType.WaterQualityDepartment);
                Employee waterQualityInspector =water.getPersonDirectory().createEmployee(RandomGenerator.getName());
                water.getUserAccountDirectory().createUserAccount(waterQualityInspector.getName(), waterQualityInspector.getName(), waterQualityInspector, new WaterQualityInspectorRole());
                
                
                Department vegetation = urbanEnvironmentalOrganization.getDepartmentDirectory().createAndAddDepartment("Vegetation Department", Department.DepartmentType.VegetationDepartment);
                Employee vegetationInspector =vegetation.getPersonDirectory().createEmployee(RandomGenerator.getName());
                vegetation.getUserAccountDirectory().createUserAccount(vegetationInspector.getName(), vegetationInspector.getName(), vegetationInspector, new VegetationInspectorRole());
                
                
                
                Employee ueAdmin = urbanEnvironmentalOrganization.getEmployeeDirectory().createEmployee(RandomGenerator.getName());
                urbanEnvironmentalOrganization.getUserAccountDirectory().createUserAccount(ueAdmin.getName(), ueAdmin.getName(), ueAdmin, new OrganizationAdminRole());
                
                UrbanPlanningOrganization urbanPlanningOrganization = (UrbanPlanningOrganization) city.getOrganizationDirectory().createAndAddOrganization("Urban Planning Organization" + String.valueOf(c), Organization.OrganizationType.UrbanPlanningOrganization);
                
                
                Department analyzing = urbanPlanningOrganization.getDepartmentDirectory().createAndAddDepartment("Analyzing Department", Department.DepartmentType.AnalyzingDepartment);
                Employee analyst = analyzing.getPersonDirectory().createEmployee(RandomGenerator.getName());
                analyzing.getUserAccountDirectory().createUserAccount(analyst.getName(), analyst.getName(), analyst, new DataAnalystRole());
                
                
                Department planning = urbanPlanningOrganization.getDepartmentDirectory().createAndAddDepartment("Strategic Planning Department", Department.DepartmentType.StrategicPlanningDepartment);
                Employee consultant =planning.getPersonDirectory().createEmployee(RandomGenerator.getName());
                planning.getUserAccountDirectory().createUserAccount(consultant.getName(), consultant.getName(), consultant, new StrategicConsultantRole());
                
                
                
                Employee upAdmin = urbanPlanningOrganization.getEmployeeDirectory().createEmployee(RandomGenerator.getName());
                urbanPlanningOrganization.getUserAccountDirectory().createUserAccount(upAdmin.getName(), upAdmin.getName(), upAdmin, new OrganizationAdminRole());
                
                
                a++;
                b++;
                c++;

                for (int dataAmount = 0; dataAmount <= 400; dataAmount++) {
                    for (Organization organization : city.getOrganizationDirectory().getOrganizationList()) {
                        //三个org
                        if (organization.getOrganizationType().equals(Organization.OrganizationType.UrbanEnvironmentalOrganization)) {
                            UrbanEnvironmentalOrganization currentUrbanEnvironmentalOrganization = (UrbanEnvironmentalOrganization) organization;
     
                            AirDataBase airDataBase = currentUrbanEnvironmentalOrganization.getAirDataBase();
                            nextAirData = RandomGenerator.initNewAirDataByLatestData(currentAirData);
                            airDataBase.addNewAirData(nextAirData);
                            currentAirData = nextAirData;

                            WaterDataBase waterDataBase = currentUrbanEnvironmentalOrganization.getWaterDataBase();
                            nextWaterData = RandomGenerator.initNewWaterDataByLatestData(currentWaterData);
                            waterDataBase.addNewWaterData(nextWaterData);
                            System.out.println("cur + next" + currentWaterData + "   "+ nextWaterData);
                            currentWaterData = nextWaterData;

                            VegetationDataBase vegetationDataBase = currentUrbanEnvironmentalOrganization.getVegetationDataBase();
                            nextVegetationData = RandomGenerator.initNewVegetationDataByLatestData(currentVegetationData);
                            vegetationDataBase.addNewVegetationData(nextVegetationData);
                            currentVegetationData = nextVegetationData;
                            
                            
                        } else if (organization.getOrganizationType().equals(Organization.OrganizationType.UrbanCensusOrganization)) {
                            UrbanCensusOrganization currentUrbanCensusOrganization = (UrbanCensusOrganization) organization;

                            HousingDataBase housingDataBase = currentUrbanCensusOrganization.getHousingDataBase();
                            nextHousingData = RandomGenerator.initNewHousingDataByLatestData(currentHousingData);
                            housingDataBase.addNewHousingData(nextHousingData);
                            currentHousingData = nextHousingData;

                            PopulationDataBase populationDataBase = currentUrbanCensusOrganization.getPopulationDataBase();
                            nextPopulationData = RandomGenerator.initNewPopulationDataByLatestData(currentPopulationData);
                            populationDataBase.addNewPopulationData(nextPopulationData);
                            currentPopulationData = nextPopulationData;

                        }
                    }
                }
            }
        }


        Employee employee = system.getEmployeeDirectory().createEmployee("zsc");
        
        UserAccount ua = system.getUserAccountDirectory().createUserAccount("admin", "admin", employee, new SystemAdminRole(Role.RoleType.SystemAdmin));
        
        return system;
    }
}
