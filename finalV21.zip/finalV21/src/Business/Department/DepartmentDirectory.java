/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Department;

import Business.Department.Department.DepartmentType;
import Business.UrbanCensusOrganization_Department.HousingDepartment;
import Business.UrbanCensusOrganization_Department.PopulationDepartment;
import Business.UrbanEnvironmentalOrganization_Department.AirQualityDepartment;
import Business.UrbanEnvironmentalOrganization_Department.VegetationDepartment;
import Business.UrbanEnvironmentalOrganization_Department.WaterQualityDepartment;
import Business.UrbanPlanningOrganization_Department.AnalyzingDepartment;
import Business.UrbanPlanningOrganization_Department.StrategicPlanningDepartment;
import java.util.ArrayList;

/**
 *
 * @author Sc Zhang
 */
public class DepartmentDirectory {
    
    private ArrayList<Department> departmentList;

    public DepartmentDirectory() {
        departmentList = new ArrayList();
    }

    public ArrayList<Department> getDepartmentList() {
        return departmentList;
    }

    public void setDepartmentList(ArrayList<Department> departmentList) {
        this.departmentList = departmentList;
    }
    
    public Department createAndAddDepartment(String name, DepartmentType departmentType){
        Department department = null;
        
        if (departmentType.equals(DepartmentType.AirQualityDepartment)){
            department = new AirQualityDepartment();
            departmentList.add(department);
        }
        else if (departmentType.equals(DepartmentType.AnalyzingDepartment)){
            department = new AnalyzingDepartment();
            departmentList.add(department);
        }
        else if (departmentType.equals(DepartmentType.HousingDepartment)){
            department = new HousingDepartment();
            departmentList.add(department);
        }
        else if (departmentType.equals(DepartmentType.PopulationDepartment)){
            department = new PopulationDepartment();
            departmentList.add(department);
        }
        else if (departmentType.equals(DepartmentType.StrategicPlanningDepartment)){
            department = new StrategicPlanningDepartment();
            departmentList.add(department);
        }
        else if (departmentType.equals(DepartmentType.VegetationDepartment)){
            department = new VegetationDepartment();
            departmentList.add(department);
        }
        else if (departmentType.equals(DepartmentType.WaterQualityDepartment)){
            department = new WaterQualityDepartment();
            departmentList.add(department);
        }
        department.setName(name);
        return department;
    }
}
