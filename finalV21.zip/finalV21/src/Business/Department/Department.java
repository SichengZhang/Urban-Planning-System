/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Department;

import Business.Employee.Employee;
import Business.Employee.EmployeeDirectory;
import Business.Role.Role;
import Business.UserAccount.UserAccountDirectory;
import Business.WorkQueue.WorkQueue;

/**
 *
 * @author Sc Zhang
 */
public abstract class Department {
    
    private String name;
    private WorkQueue workQueue;
    private EmployeeDirectory personDirectory;
    private UserAccountDirectory userAccountDirectory;
    private int DepartmentID;
    private static int counter;
    private DepartmentType departmentType;
    
    public Department(DepartmentType departmentType){
        this.departmentType = departmentType;
        personDirectory= new EmployeeDirectory();
        workQueue = new WorkQueue();
        userAccountDirectory = new UserAccountDirectory();
        DepartmentID = counter++;
    }

    public abstract Role getSupportedRole();
    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public WorkQueue getWorkQueue() {
        return workQueue;
    }

    public void setWorkQueue(WorkQueue workQueue) {
        this.workQueue = workQueue;
    }

    public EmployeeDirectory getPersonDirectory() {
        return personDirectory;
    }

    public void setPersonDirectory(EmployeeDirectory personDirectory) {
        this.personDirectory = personDirectory;
    }

    public UserAccountDirectory getUserAccountDirectory() {
        return userAccountDirectory;
    }

    public void setUserAccountDirectory(UserAccountDirectory userAccountDirectory) {
        this.userAccountDirectory = userAccountDirectory;
    }

    public int getDepartmentID() {
        return DepartmentID;
    }

    public void setDepartmentID(int DepartmentID) {
        this.DepartmentID = DepartmentID;
    }

    
    
    
    
    public enum DepartmentType{
        HousingDepartment("Housing Department"), 
        PopulationDepartment("Population Department"),
        AirQualityDepartment("Air Quality Department"),
        VegetationDepartment("Vegetation Department"),
        WaterQualityDepartment("Water Quality Department"),
        AnalyzingDepartment("Analyzing Department"),
        
        StrategicPlanningDepartment("Strategic Planning Department");
        
        private String value;
        
        private DepartmentType(String value) {
            this.value = value;
        }
        public String getValue() {
            return value;
        }
    }

    @Override
    public abstract String toString();
    
    
}
