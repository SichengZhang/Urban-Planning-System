/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Data;


import java.util.Random;

/**
 *
 * @author Lig37
 */
public class RandomGenerator {

    public Random random;
//limit two decimal double method: Math.round(number*100.0)/100.0;
//Person 相关
    
    
    //Person Name pool
        static String[] names = {"Anderson", "Bailey", "Baker", "Barker", "Barnes",
        "Begum", "Bell", "Bennett", "Brown", "Butler",
        "Campbell", "Carter", "Chapman", "Clark", "Clarke",
        "Collins", "Cook", "Cooper", "Cox", "Davies",
        "Davis", "Dixon", "Edwards", "Ellis", "Evans",
        "Fisher", "Foster", "Gray", "Green", "Griffiths",
        "Hall", "Harris", "Harrison", "Harvey", "Hill",
        "Holmes", "Hughes", "Hunt", "Hussain", "Jackson",
        "James", "Jenkins", "Johnson", "Jones", "Kelly",
        "Khan", "King", "Knight", "Lee", "Lewis",
        "Lloyd", "Marshall", "Martin", "Mason", "Matthews",
        "Miller", "Mills", "Mitchell", "Moore", "Morgan",
        "Morris", "Murphy", "Murray", "Owen", "Palmer",
        "Parker", "Patel", "Phillips", "Powell", "Price",
        "Richards", "Richardson", "Roberts", "Robinson", "Rogers",
        "Russell", "Scott", "Shaw", "Simpson", "Singh",
        "Smith", "Stevens", "Taylor", "Thomas", "Thompson",
        "Turner", "Walker", "Ward", "Watson", "Webb",
        "White", "Wilkinson", "Williams", "Wilson", "Wood","Aali", "Aaliyah", "Aaron", "Abigail", "Abraham",
       "Abram", "Ad", "Adal", "Adam", "Adela",
       "Adelaide", "Adelbert", "Adele", "Adelheid", "Adeline",
       "Adolf", "Adolph", "Adrian", "Adriana", "Aegidius",
       "Aemulus", "Agatha", "Agnes", "Aidan", "Ainsley",
       "Al", "Alaina", "Alan", "Alana", "Alanis",
       "Alannah", "Albanus", "Alberich", "Albert", "Aldo",
       "Alesia", "Alessandra", "Aletha", "Alethea", "Alex",
       "Alexa", "Alexander", "Alexandra", "Alexandria", "Alexia",
       "Alexis", "Alexus", "Alfonso", "Alfred", "Alfreda",
       "Algar", "Ali", "Alice", "Alicia", "Aline",
       "Alison", "Allegra", "Alonzo", "Alvah", "Alvin",
       "Alvina", "Alyssa", "Amabilis", "Amal", "Amanda",
       "Amandus", "Amata", "Amber", "Ambrose", "Ambrosius",
       "Amelia", "Amerigo", "Amicitia", "Amis", "Amy",
       "Amyas", "An", "Ana", "Anacletus", "Anastasia",
       "Anastasius", "Ancient", "Andr", "Andra", "Andre",
       "Andrea", "Andrew", "Angel", "Angela", "Angelica",
       "Angelicus", "Angelo", "Angelus", "Anglicized", "Angus",
       "Ann", "Anna", "Annabel", "Anne", "Annika",
       "Annis", "Anselm", "Anselma", "Antha", "Anthony",
       "Antoine", "Antonia", "Antonius", "Aodh", "Aonghus",
       "Aperire", "April", "Araminta", "Archibald", "Ariana",
       "Ariane", "Arianna", "Ariel", "Arline", "Arnold",
       "Arr", "Arthur", "Arwel", "Ashley", "Ashlyn",
       "Astur", "Asu", "Atten", "Aubrey", "Audrey",
       "Augusta", "Augustine", "Augustus", "Aur", "Aura",
       "Aureolus", "Austin", "Autumnus", "Aux", "Aveline",
       "Avi", "Avila", "Avis", "Azure", "Bailey",
       "Baili", "Bairre", "Bald", "Bambina", "Barbara",
       "Barnabas", "Barnaby", "Barrett", "Barry", "Bartholomew",
       "Basilica", "Beatrice", "Beatrix", "Beauvais", "Bedelia",
       "Bel", "Belinda", "Bella", "Belle", "Benedict",
       "Benedictus", "Benjamin", "Beorht", "Beorn", "Beraht"};
//sample while using   
    public static String getName(){
        Random random = new Random();
        int Name = random.nextInt(names.length);
        return names[Name];
    }

    
     
     
//user Account 相关
   
     //user name pool-没设，感觉 username最好根据person生成，这样可以规定特定格式的
    //City related: cityNames[random.nextInt(cityNameas.length)]
     static String[] cityNames = {"Abington", "Acton", "Acushnet", "Adams", "Agawam",
        "Alford", "Amesbury", "Amherst", "Andover", "Aquinnah",
        "Arlington", "Ashburnham", "Ashby", "Ashfield", "Ashland",
        "Athol", "Attleboro", "Auburn", "Avon", "Ayer",
        "Barnstable", "Barre", "Becket", "Bedford", "Belchertown",
        "Bellingham", "Belmont", "Berkley", "Berlin", "Bernardston",
        "Beverly", "Billerica", "Blackstone", "Blandford", "Bolton",
        "Boston", "Bourne", "Boxborough", "Boxford", "Boylston",
        "Braintree", "Brewster", "Bridgewater", "Brimfield", "Brockton",
        "Pembroke", "Pepperell", "Peru", "Petersham", "Phillipston",
        "Pittsfield", "Plainfield", "Plainville", "Plymouth", "Plympton",
        "Princeton", "Provincetown", "Quincy", "Randolph", "Raynham",
        "Reading", "Rehoboth", "Revere", "Richmond", "Rochester",
        "Rockland", "Rockport", "Rowe", "Rowley", "Royalston",
        "Russell", "Rutland", "Salem", "Salisbury", "Sandisfield",
        "Sandwich", "Saugus", "Savoy", "Scituate", "Seekonk",
        "Williamstown", "Wilmington", "Winchendon", "Winchester", "Windsor",
        "Winthrop", "Woburn", "Worcester", "Worthington", "Wrentham"};
    
     
     
    public static String getCityName(){
        Random random = new Random();
        int Name = random.nextInt(cityNames.length);
        return cityNames[Name];
    }
    //community related
    static String[] communityName = {"Plymouth", "Middlesex", "Bristol", "Berkshire", "Hampden", "Essex",
       "Hampshire", "Dukes", "Worcester", "Franklin", "Norfolk", "Barnstable", "Suffolk", "Nantucket",};
    
    public static String getStateName(){
        Random random = new Random();
        int Name = random.nextInt(communityName.length);
        return communityName[Name];
    }
    //year,month-最好forloop连续生成，这样不会重复，但这边先写了防止要用
//    String year = String.valueOf(random.nextInt( 1800 - 2017 + 1) + 1800);
//    String month = String.valueOf(random.nextInt( 1 - 12 + 1) + 1);
    
    //air data related
    double pmConcentration = Math.round((0.00 + (500.00 - 0.00) * random.nextGaussian())*100.0)/100.0;
    double so2Concentration =Math.round((0.00 + (2620.00 - 0.00) * random.nextGaussian())*100.0)/100.0;
    double coConcentration = Math.round((0.00 + (60.00 - 0.00) * random.nextGaussian())*100.0)/100.0;
//    double Clow = 0.00 + (350.5 - 0.00) * random.nextDouble();
//    double Chigh = 15.4 + (500.4 - 15.4) * random.nextDouble();
//    double Ilow = 40.00 + (401.0 - 0.00) * random.nextDouble();
//    double Ihigh = 50.00 + (500.0 - 50.00) * random.nextDouble();
    
    
    //water data related
    double pH = Math.round((6.0 + (9.0 - 6.0) * random.nextGaussian())*100.0)/100.0;
    double dissolvedOxygen = Math.round((2.0 + (16.0 - 2.0) * random.nextGaussian())*100.0)/100.0;//unit:mg/L
    double suspendedSolids = Math.round((0.0 + (40.0 - 0.0)* random.nextGaussian())*100.0)/100.0;//unit: mg/L
    double turbidity = Math.round((0.0 + (900.0 - 0.0)* random.nextGaussian())*100.0)/100.0;//unit: NTU
    double temperature = Math.round((0.0 + (50.0 - 0.0)* random.nextGaussian())*100.0)/100.0;//unit:摄氏度C
    double bod = Math.round((0.0 + (10.0 - 0.0)* random.nextGaussian())*100.0)/100.0;//unit:mg/L
    //population data related

    int populationNumber = (int)(1000000.0+(100000000-1000000.0)*random.nextGaussian());//随便设的range，不过有个问题，一个城市，两年的人口自动生成差太多咋办？
    private double consumptionPerCapita =Math.round(( 2.0 + (140.0 - 0.0)* random.nextGaussian())*100.0)/100.0;//需改成double-需要加个变量，按cpc的值推导对cc的affluence
    //加的,也分5档h,median-h,m,m-l,l
    //private int consumptionFactor 
    private int technologyFactor = random.nextInt( 5 - 1 + 1) + 1;//没找到。。我随便设了，分五个档
    int lifeExpactancy = (int)(60.0+(100-60.0)*random.nextGaussian());//正常寿命0-120；
    int meanYearsOfSchooling = (int)(6.0+(30-6.0)*random.nextGaussian());//高等教育-6年义务教育
    int expectedYearsOfSchooling = (int)(6.0+(30-6.0)*random.nextGaussian());
    private double incomeIndex = 0.2 + (0.9 - 0.2)* random.nextGaussian();//II
    
    
    
    //vegetation data related
//    
//    int year1  = random.nextInt(2017 - 1800 + 1) + 1800;//20
//    int year2  = year1+1;//此处只求相隔一年的deforest rate还是你们觉得要都random generate？反正我后面是用公式算的，也行
    double forestArea = random.nextInt(10000 + (10000000 -10000) );
    double totalArea = random.nextInt(100000 + (100000000 -500000) * random.nextInt());
    double greenArea = totalArea*(0.0 + (0.7 - 0.0)* random.nextGaussian());//假设一个目测合理范围
    
    double OpenSpaceOnRedidential = random.nextInt(10000 + (10000000 -10000) );
    double totalAreaOfEntireParcel = random.nextInt(100000 + (100000000 -500000) * random.nextInt());
    double openSpaceOnNonresidental = totalArea*(0.0 + (0.7 - 0.0)* random.nextGaussian());//假设一个目测合理范围
    
    //housing data related
    int noticesOfForeclousre =  random.nextInt(2017 - 1800 + 1) + 1800;
    int salesVolume = random.nextInt(5000- 1000 + 1) + 1000 ;
    int medianSalesPricePerUnit = random.nextInt(2000 - 200 + 1) + 200;//unit: thousand dollar
    double indexOfHousingPriceAppreciation = Math.round((-0.02 + (1 + 0.02) * random.nextGaussian())*100.0)/100.0;//unit %; 
    int unitsAuthorized = random.nextInt(8000- 1000 + 1) + 1000 ;//new residential permit
 
    
    
    //random stuff:
    //method for getting Greatest Common Divisor
    public int GreatestCommonDivisor(int a, int b){
    int r;
    if(b == 0)
        return -1;
    while((r= a%b)!= 0){
    a = b;
    b = r;
    }
    return b;
    }//digit1/greatestCommonDivisor:digit2/greatestCommonDivisor最简分数比
    
//   for(int year = 1800,year<=2017,year++){
//    for(int month = 1,month <= 12, month++){
//    }
//    }
    
    
    public static AirData initFirstAirData(int createMonth, int createYear) {
          Random random = new Random();
          AirData airData = new AirData();
          //air data related
          double pmConcentration;
          double pmConcentrationTest;
          do{
              pmConcentrationTest = Math.round((250 + 100 * random.nextGaussian()) * 100.0) / 100.0;
          }
          while(pmConcentrationTest < 0 || pmConcentrationTest > 500);
          pmConcentration = pmConcentrationTest;
          
          
          double so2Concentration;
          double so2ConcentrationTest;
          do{
              so2ConcentrationTest = Math.round((1310 + 524 * random.nextGaussian()) * 100.0) / 100.0;
          }
          while(so2ConcentrationTest < 0 || so2ConcentrationTest > 2620);
           so2Concentration = so2ConcentrationTest;
          
          double coConcentration;
          double coConcentrationTest;
          do{
             coConcentrationTest = Math.round((30+ 24 * random.nextGaussian()) * 100.0) / 100.0;
          }
          while(coConcentrationTest < 0 || coConcentrationTest > 60);
          coConcentration = coConcentrationTest;
          
          airData.setPmConcentration(pmConcentration);
          airData.setSo2Concentration(so2Concentration);
          airData.setCoConcentration(coConcentration);
          airData.setCreateMonth(String.valueOf(createMonth));
          airData.setCreateYear(String.valueOf(createYear));
          return airData;
          
      
  }
    public static AirData initNewAirDataByLatestData(AirData airData){
        Random random = new Random();
        AirData newAirData = new AirData();
        
        double pmConcentration = Math.round((250 + 100 * random.nextGaussian()) * 100.0) / 100.0;
        double so2Concentration = Math.round((1310 + 524 * random.nextGaussian()) * 100.0) / 100.0;
        double coConcentration = Math.round((30+ 24 * random.nextGaussian()) * 100.0) / 100.0;
        
        String year;
        String month;
        if(airData.getCreateMonth().equals("12")){
            year = String.valueOf(Integer.parseInt(airData.getCreateYear()) + 1);
            month = "1";
        }
        else {
            year = airData.getCreateYear();
            month = String.valueOf(Integer.parseInt(airData.getCreateMonth()) + 1);
        }
        
        
        newAirData.setCoConcentration(coConcentration);
        newAirData.setSo2Concentration(so2Concentration);
        newAirData.setPmConcentration(pmConcentration);
        newAirData.setCreateMonth(month);
        newAirData.setCreateYear(year);
        newAirData.setYearMonth(year + "/" + month);
        
        return newAirData;
    }
    
    public static HousingData initHousingData(int createMonth, int createYear) {
        Random random = new Random();
            HousingData h0 = new HousingData();
            int noticesOfForeclousre;
            do{
               int noticesOfForeclousretest = (int)(200 + 80 * random.nextGaussian());
               noticesOfForeclousre = noticesOfForeclousretest;
            }
            while(
                    noticesOfForeclousre <=0 || noticesOfForeclousre >=400
                 );
             
            
            int salesVolume;
            do{
               int salesVolumetest = (int)(3000 + 800 * random.nextGaussian());
               salesVolume = salesVolumetest;
            }
            while(
                    salesVolume <=1000 || salesVolume >=5000
                 );
            
            int medianSalesPricePerUnit;//unit: thousand dollar
            do{
               int medianSalesPricePerUnittest = (int)(50 + 12 * random.nextGaussian());
               medianSalesPricePerUnit = medianSalesPricePerUnittest;
            }
            while(
                    medianSalesPricePerUnit <=20  || medianSalesPricePerUnit >=80
                 );
            
            double indexOfHousingPriceAppreciation;//unit %
            do{
               double indexOfHousingPriceAppreciationtest = 0.04 + 0.204 * random.nextGaussian();
               indexOfHousingPriceAppreciation = indexOfHousingPriceAppreciationtest;
            }
            while(
                    indexOfHousingPriceAppreciation <= -0.02 || indexOfHousingPriceAppreciation >=1
                 );
            
            int unitsAuthorized;//unit %
            do{
               int unitsAuthorizedtest = (int)(4500 + 1400 * random.nextGaussian());
               unitsAuthorized = unitsAuthorizedtest;
            }
            while(
                    unitsAuthorized <=1000 || unitsAuthorized >=7000
                 );
            
            h0.setNoticesOfForeclousre(noticesOfForeclousre);
            h0.setSalesVolume(salesVolume);
            h0.setMedianSalesPricePerUnit(medianSalesPricePerUnit);
            h0.setIndexOfHousingPriceAppreciation(indexOfHousingPriceAppreciation);
            h0.setUnitsAuthorized(unitsAuthorized);
            h0.setCreateMonth(String.valueOf(createMonth));
            h0.setCreateYear(String.valueOf(createYear));
           
            
            return h0;
  
    }

    public static HousingData initNewHousingDataByLatestData(HousingData housingData){
       Random random = new Random();
       HousingData newHousingData = new HousingData();
       
       int noticesOfForeclousre = (int)(housingData.getNoticesOfForeclousre() * (1+0.04*random.nextGaussian()));
       int salesVolume = (int)(housingData.getSalesVolume() * (1+0.04*random.nextGaussian()));
       int medianSalesPricePerUnit = (int)(housingData.getMedianSalesPricePerUnit()* (1+0.04*random.nextGaussian()));
       double indexOfHousingPriceAppreciation = housingData.getIndexOfHousingPriceAppreciation()* (1+0.04*random.nextGaussian());
       int unitsAuthorized = (int)(housingData.getUnitsAuthorized() * (1+0.04*random.nextGaussian()));
       
       String year;
       String month;
       if(housingData.getCreateMonth().equals("12")){
           year = String.valueOf(Integer.parseInt(housingData.getCreateYear()) + 1);
           month = "1";
       }
       else {
           year = housingData.getCreateYear();
           month = String.valueOf(Integer.parseInt(housingData.getCreateMonth()) + 1);
       }
       
       
       newHousingData.setNoticesOfForeclousre(noticesOfForeclousre);
       newHousingData.setSalesVolume(salesVolume);
       newHousingData.setMedianSalesPricePerUnit(medianSalesPricePerUnit);
       newHousingData.setIndexOfHousingPriceAppreciation(indexOfHousingPriceAppreciation);
       newHousingData.setUnitsAuthorized(unitsAuthorized);
       newHousingData.setCreateMonth(month);
       newHousingData.setCreateYear(year);
       
       return newHousingData;
   }
    
   
    public static WaterData initFirstWaterData(int createMonth, int createYear) {
           Random random = new Random();
           WaterData w0 = new WaterData();
           
           double pH;
           double pHTest;
           do{
               pHTest =  Math.round((7.5+0.6*random.nextGaussian())* 100.0) / 100.0;
           }
           while(pHTest < 6.0 || pHTest>9.0);
           
           pH = pHTest;
          
           double dissolvedOxygen;
           double dissolvedOxygenTest;
           do{
               dissolvedOxygenTest = Math.round((9.0+2.8* random.nextGaussian()) * 100.0) / 100.0;
           }
           while(dissolvedOxygenTest >16.0 || dissolvedOxygenTest<2.0);
           dissolvedOxygen = dissolvedOxygenTest;
           double suspendedSolids;
           double suspendedSolidsTest;
           do{
               suspendedSolidsTest =  Math.round((20.0+8.0 * random.nextGaussian()) * 100.0) / 100.0;
           }
           while(suspendedSolidsTest < 0.0|| suspendedSolidsTest>40.0);
           suspendedSolids = suspendedSolidsTest;
           double turbidity;
           double turbidityTest;
           do{
               turbidityTest =  Math.round((450+180 * random.nextGaussian()) * 100.0) / 100.0;
           }
           while(turbidityTest < 0.0|| turbidityTest>900.0);
           turbidity = turbidityTest;
           double temperature ;
           double temperatureTest;
           do{
               temperatureTest =  Math.round((25.0+10.0*random.nextGaussian())* 100.0) / 100.0;
           }
           while(temperatureTest < 0.0 || temperatureTest>50.0);
           temperature  = temperatureTest;
           double bod  ;
           double bodTest;
           do{
               bodTest =  Math.round((5+2 * random.nextGaussian()) * 100.0) / 100.0;
           }
           while(bodTest < 0.0 || bodTest>10.0);
           bod = bodTest;
            w0.setBod5(bod);
            w0.setDissolvedOxygen(dissolvedOxygen);
            w0.setSuspendedSolids(suspendedSolids);
            w0.setpH(pH);
            w0.setTemperature(temperature);
            w0.setTurbidity(turbidity);
            w0.setCreateMonth(String.valueOf(createMonth));
            w0.setCreateYear(String.valueOf(createYear));
            return w0;
    }
    
    public static WaterData initNewWaterDataByLatestData(WaterData waterData){
       Random random = new Random();
       WaterData newWaterData = new WaterData();
       //Math.round((71+27.6 * random.nextGaussian()) * 100.0) / 100.0
       double pH = Math.round((waterData.getpH() * (1+0.04*random.nextGaussian())) * 100.0) / 100.0;
       double dissolvedOxygen = Math.round((waterData.getDissolvedOxygen() * (1+0.04*random.nextGaussian())) * 100.0) / 100.0;
       double suspendedSolids = Math.round((waterData.getSuspendedSolids()* (1+0.04*random.nextGaussian())) * 100.0) / 100.0;
       double turbidity = Math.round((waterData.getTurbidity()* (1+0.04*random.nextGaussian())) * 100.0) / 100.0;
       double temperature = Math.round((waterData.getTemperature()* (1+0.04*random.nextGaussian())) * 100.0) / 100.0;
       double bod = Math.round((waterData.getBod5()* (1+0.04*random.nextGaussian())) * 100.0) / 100.0;
       
       String year;
       String month;
       if(waterData.getCreateMonth().equals("12")){
           year = String.valueOf(Integer.parseInt(waterData.getCreateYear()) + 1);
           month = "1";
       }
       else {
           year = waterData.getCreateYear();
           month = String.valueOf(Integer.parseInt(waterData.getCreateMonth()) + 1);
       }
       
       
       newWaterData.setpH(pH);
       newWaterData.setDissolvedOxygen(dissolvedOxygen);
       newWaterData.setSuspendedSolids(suspendedSolids);
       newWaterData.setTurbidity(turbidity);
       newWaterData.setTemperature(temperature);
       newWaterData.setBod5(bod);
       newWaterData.setCreateMonth(month);
       newWaterData.setCreateYear(year);
       newWaterData.setYearMonth(year + "/" + month);
       
       return newWaterData;
   }
    
    public static PopulationData initFirstPopulationrData(int createMonth, int createYear) {
           Random random = new Random();
           PopulationData p0 = new PopulationData();
//            int expectedYearsOfSchooling 
//            double incomeIndex =
               int populationNumber;
               int populationNumberTest;
               do {
                   populationNumberTest= (int) (10500000+3800000 * random.nextGaussian());//1000,000-20,000,000
               } while (populationNumberTest< 1000000 || populationNumberTest>20000000);
               populationNumber = populationNumberTest;
               
               double consumptionPerCapita;
               double consumptionPerCapitaTest;
               do {
                   consumptionPerCapitaTest= Math.round((71+27.6 * random.nextGaussian()) * 100.0) / 100.0;//140-2
               } while (consumptionPerCapitaTest< 2|| consumptionPerCapitaTest>140);
               consumptionPerCapita = consumptionPerCapitaTest;
               
               int technologyFactor;
               int technologyFactorTest;
               do {
                   technologyFactorTest= random.nextInt(5 - 1 + 1) + 1;//没找到。。我随便设了，分五个档5-1
               } while (technologyFactorTest< 1 || technologyFactorTest>5);
               technologyFactor = technologyFactorTest;
               
               int lifeExpactancy;
               int lifeExpactancyTest;
               do {
                   lifeExpactancyTest= (int) (80+8 * random.nextGaussian());//正常寿命0-120；average60-100
               } while (lifeExpactancyTest< 60 || lifeExpactancyTest>100);
               lifeExpactancy = lifeExpactancyTest;
               
               int meanYearsOfSchooling;
               int meanYearsOfSchoolingTest;
               do {
                   meanYearsOfSchoolingTest= (int) (18+4.8* random.nextGaussian());//30高等教育-6年义务教育
               } while (meanYearsOfSchoolingTest< 6 || meanYearsOfSchoolingTest>30);
               meanYearsOfSchooling = meanYearsOfSchoolingTest;
               
               int expectedYearsOfSchooling;
               int expectedYearsOfSchoolingTest;
               do {
                   expectedYearsOfSchoolingTest=(int) (18+4.8* random.nextGaussian());//30-6
               } while (expectedYearsOfSchoolingTest< 6|| expectedYearsOfSchoolingTest>30);
               expectedYearsOfSchooling = expectedYearsOfSchoolingTest;
               double incomeIndex;
               double incomeIndexTest;
               do {
                   incomeIndexTest=  Math.round((0.55+0.14 * random.nextGaussian()) * 100.0) / 100.0;//II 0.2-0.9
               } while (incomeIndexTest< 0.2 || incomeIndexTest>0.9);
               incomeIndex = incomeIndexTest;
               
            p0.setPopulationNumber(populationNumber);
            p0.setExpectedYearsOfSchooling(expectedYearsOfSchooling);
            p0.setIncomeIndex(incomeIndex);
            p0.setLifeExpactancy(lifeExpactancy);
            p0.setMeanYearsOfSchooling(meanYearsOfSchooling);
            p0.setTechnologyFactor(technologyFactor);
            p0.setConsumptionPerCapita((int) consumptionPerCapita);
            p0.setCreateMonth(String.valueOf(createMonth));
            p0.setCreateYear(String.valueOf(createYear));
            return p0;
       
    }

    
    public static PopulationData initNewPopulationDataByLatestData(PopulationData populationData) {
        Random random = new Random();
        PopulationData p0 = new PopulationData();
           
        int populationNumber;
        int populationNumberTest;
        do {
            populationNumberTest = (int) (populationData.getPopulationNumber() * (1 + 0.04 * random.nextGaussian()));//1000,000-20,000,000
        } while (populationNumberTest < 1000000 || populationNumberTest > 20000000);
        populationNumber = populationNumberTest;

        double consumptionPerCapita;
        double consumptionPerCapitaTest;
        do {
            consumptionPerCapitaTest = populationData.getConsumptionPerCapita() * (1 + 0.04 * random.nextGaussian());//140-2
        } while (consumptionPerCapitaTest < 2 || consumptionPerCapitaTest > 140);
        consumptionPerCapita = consumptionPerCapitaTest;

        int technologyFactor;
        int technologyFactorTest;
        do {
            technologyFactorTest = (int) (populationData.getTechnologyFactor() * (1 + 0.04 * random.nextGaussian()));//没找到。。我随便设了，分五个档5-1
        } while (technologyFactorTest < 1 || technologyFactorTest > 5);
        technologyFactor = technologyFactorTest;

        int lifeExpactancy;
        int lifeExpactancyTest;
        do {
            lifeExpactancyTest = (int) (populationData.getLifeExpactancy() * (1 + 0.04 * random.nextGaussian()));//正常寿命0-120；average60-100
        } while (lifeExpactancyTest < 60 || lifeExpactancyTest > 100);
        lifeExpactancy = lifeExpactancyTest;
        int meanYearsOfSchooling;
        int meanYearsOfSchoolingTest;
        do {
            meanYearsOfSchoolingTest = (int) (populationData.getMeanYearsOfSchooling() * (1 + 0.04 * random.nextGaussian()));//30高等教育-6年义务教育
        } while (meanYearsOfSchoolingTest < 6 || meanYearsOfSchoolingTest > 30);
        meanYearsOfSchooling = meanYearsOfSchoolingTest;
        int expectedYearsOfSchooling;
        int expectedYearsOfSchoolingTest;
        do {
            expectedYearsOfSchoolingTest = (int) (populationData.getExpectedYearsOfSchooling() * (1 + 0.04 * random.nextGaussian()));//30-6
        } while (expectedYearsOfSchoolingTest < 6 || expectedYearsOfSchoolingTest > 30);
        expectedYearsOfSchooling = expectedYearsOfSchoolingTest;
        double incomeIndex;
        double incomeIndexTest;
        do {
            incomeIndexTest = populationData.getIncomeIndex() * (1 + 0.04 * random.nextGaussian());//II 0.2-0.9
        } while (incomeIndexTest < 0.2 || incomeIndexTest > 0.9);
        incomeIndex = incomeIndexTest;

        String year;
        String month;
        if (populationData.getCreateMonth().equals("12")) {
            year = String.valueOf(Integer.parseInt(populationData.getCreateYear()) + 1);
            month = "1";
        } else {
            year = populationData.getCreateYear();
            month = String.valueOf(Integer.parseInt(populationData.getCreateMonth()) + 1);
        }

        p0.setPopulationNumber(populationNumber);
        p0.setExpectedYearsOfSchooling(expectedYearsOfSchooling);
        p0.setIncomeIndex(incomeIndex);
        p0.setLifeExpactancy(lifeExpactancy);
        p0.setMeanYearsOfSchooling(meanYearsOfSchooling);
        p0.setTechnologyFactor(technologyFactor);
        p0.setConsumptionPerCapita((int) consumptionPerCapita);
        p0.setCreateMonth(month);
        p0.setCreateYear(year);
        return p0;

    }
    
    public static VegetationData initFirstVegetationData(int createMonth, int createYear) {
           Random random = new Random();
           VegetationData v0 = new VegetationData();
                      
           double forestArea;
           double forestAreaTest;
           do{
               forestAreaTest = random.nextInt((10000000 - 10000)) + 10000;
           }
           while(forestAreaTest < 10000 || forestAreaTest>10000000);
           forestArea = forestAreaTest;
           double totalArea;
           double totalAreaTest;
           do{
               totalAreaTest = Math.round((800+280 * random.nextGaussian())* 100.0 / 100.0);
           }
           while(totalAreaTest < 100 || totalAreaTest>1500);
           totalArea = totalAreaTest;
           double greenArea;
           double greenAreaTest;
           do{
               greenAreaTest = Math.round(totalArea * (0.2+0.08 * random.nextGaussian()) * 100.0 / 100.0);
           }
           while(greenAreaTest < 40 || greenAreaTest > 600);
           greenArea = greenAreaTest;
           
           double totalAreaOfEntireParcel;
           double totalAreaOfEntireParcelTest;
           do{
               totalAreaOfEntireParcelTest = Math.round(totalArea * (0.2+0.08 * random.nextGaussian()) * 100.0 / 100.0);
           }
           while(totalAreaOfEntireParcelTest < 40 || totalAreaOfEntireParcelTest>600);
           totalAreaOfEntireParcel = totalAreaOfEntireParcelTest;
           
           double openSpaceOnRedidential;
           double openSpaceOnRedidentialTest;
           do{
               openSpaceOnRedidentialTest =  Math.round(totalAreaOfEntireParcel * (0.15+0.06 * random.nextGaussian()) * 100.0 / 100.0);
           }
           while(openSpaceOnRedidentialTest < 12 || openSpaceOnRedidentialTest>180);
           openSpaceOnRedidential = openSpaceOnRedidentialTest;
           
           double openSpaceOnNonresidental;
           openSpaceOnNonresidental = totalAreaOfEntireParcel - openSpaceOnRedidential;
           
            
            v0.setForestArea(forestArea);
            v0.setGreenArea(greenArea);
            v0.setTotalArea(totalArea);
            v0.setOpenSpaceOnRedidential(openSpaceOnRedidential);
            v0.setOpenSpaceOnNonresidental(openSpaceOnNonresidental);
            v0.setTotalAreaOfEntireParcel(totalAreaOfEntireParcel);
            v0.setCreateMonth(String.valueOf(createMonth));
            v0.setCreateYear(String.valueOf(createYear));
            return v0;
}
    
    public static VegetationData initNewVegetationDataByLatestData(VegetationData vegetationData){
       Random random = new Random();
       VegetationData newVegetationData = new VegetationData();
       //Math.round((71+27.6 * random.nextGaussian()) * 100.0) / 100.0
       double forestArea = Math.round((vegetationData.getForestArea() * (1+0.04*random.nextGaussian()))* 100.0) / 100.0;
       double greenArea = Math.round((vegetationData.getGreenArea() * (1+0.04*random.nextGaussian()))* 100.0) / 100.0;
       double totalArea = Math.round((vegetationData.getTotalArea()* (1+0.04*random.nextGaussian()))* 100.0) / 100.0;
       double OpenSpaceOnRedidential = Math.round((vegetationData.getOpenSpaceOnRedidential()* (1+0.04*random.nextGaussian()))* 100.0) / 100.0;
       double totalAreaOfEntireParcel = Math.round((vegetationData.getTotalAreaOfEntireParcel()* (1+0.04*random.nextGaussian()))* 100.0) / 100.0;
       double openSpaceOnNonresidental = Math.round((vegetationData.getOpenSpaceOnRedidential()* (1+0.04*random.nextGaussian()))* 100.0) / 100.0;
       
       String year;
       String month;
       if(vegetationData.getCreateMonth().equals("12")){
           year = String.valueOf(Integer.parseInt(vegetationData.getCreateYear()) + 1);
           month = "1";
       }
       else {
           year = vegetationData.getCreateYear();
           month = String.valueOf(Integer.parseInt(vegetationData.getCreateMonth()) + 1);
       }
       
       
       newVegetationData.setForestArea(forestArea);
       newVegetationData.setGreenArea(greenArea);
       newVegetationData.setTotalArea(totalArea);
       newVegetationData.setOpenSpaceOnRedidential(OpenSpaceOnRedidential);
       newVegetationData.setTotalAreaOfEntireParcel(totalAreaOfEntireParcel);
       newVegetationData.setOpenSpaceOnNonresidental(openSpaceOnNonresidental);
       newVegetationData.setCreateMonth(month);
       newVegetationData.setCreateYear(year);
       newVegetationData.setYearMonth(year + "/" + month);
       
       return newVegetationData;
   } 
}

