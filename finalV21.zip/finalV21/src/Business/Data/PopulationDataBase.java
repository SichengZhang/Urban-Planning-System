/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Data;

import java.util.HashMap;

/**
 *
 * @author Lig37
 */
public class PopulationDataBase {
    private HashMap<String,HashMap<String,PopulationData>> populationHMap;
     
     
     public PopulationDataBase(){
         populationHMap = new HashMap();
     }

    public HashMap<String, HashMap<String, PopulationData>> getPopulationHMap() {
        return populationHMap;
    }

    public HashMap<String, PopulationData> getInnerHMap(String year){
        return populationHMap.get(year);
    }
    
    public void setPopulationHMap(HashMap<String, HashMap<String, PopulationData>> populationHMap) {
        this.populationHMap = populationHMap;
    }
     
     
//        
//    public PopulationData addNewPopulationData(){
//        PopulationData populationData = new PopulationData();
//        for (String year : populationHMap.keySet()){
//            if (year.equals(populationData.getCreateYear())){
//                populationHMap.get(year).put(populationData.getCreateMonth(), populationData);
//            }
//            else {
//                HashMap<String, PopulationData> innerPopulationHMap = new HashMap();
//                populationHMap.put(populationData.getCreateYear(), innerPopulationHMap);
//                innerPopulationHMap.put(populationData.getCreateMonth(), populationData);
//            }
//        }
//        return populationData;
//}

        public void addNewPopulationData(PopulationData populationData){
       if (populationHMap.containsKey(populationData.getCreateYear())){
           populationHMap.get(populationData.getCreateYear()).put(populationData.getCreateMonth(), populationData);
       }
       else{
           HashMap<String, PopulationData> innerPopulationHMap = new HashMap();
           populationHMap.put(populationData.getCreateYear(), innerPopulationHMap);
           innerPopulationHMap.put(populationData.getCreateMonth(), populationData);
       }
   }
        
        public PopulationData searchBySerialNumber(int dataSerialNumber) {
        PopulationData result = null;
        result = new PopulationData();
        for (HashMap<String, PopulationData> hMap : populationHMap.values()) {
            for (PopulationData populationData : hMap.values()) {
                if (populationData.getId() == dataSerialNumber) {
                    result = populationData;
                    return result;
                }
                 return null;
            }
        }
       return result;
    }
    
}
