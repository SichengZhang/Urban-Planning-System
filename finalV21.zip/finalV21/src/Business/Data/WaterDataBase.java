/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Data;

import java.util.HashMap;

/**
 *
 * @author Lig37
 */
public class WaterDataBase {
    private HashMap<String, HashMap<String, WaterData>> waterHMap;
    
    public WaterDataBase(){
        waterHMap = new HashMap();
    }

    public HashMap<String, HashMap<String, WaterData>> getWaterHMap() {
        return waterHMap;
    }

    public void setWaterHMap(HashMap<String, HashMap<String, WaterData>> waterHMap) {
        this.waterHMap = waterHMap;
    }
     
    public HashMap<String, WaterData> getInnerHMap(String year){
        return waterHMap.get(year);
    }

    
    public void addNewWaterData(WaterData waterData) {
        if (waterHMap.keySet().contains(waterData.getCreateYear())) {
            waterHMap.get(waterData.getCreateYear()).put(waterData.getCreateMonth(), waterData);
        } else {
            HashMap<String, WaterData> innerAirHMap = new HashMap();
            waterHMap.put(waterData.getCreateYear(), innerAirHMap);
            innerAirHMap.put(waterData.getCreateMonth(), waterData);
        }
    
    }
    
     public WaterData searchBySerialNumber(int dataSerialNumber) {
        WaterData result = new WaterData();
        for (HashMap<String, WaterData> hMap : waterHMap.values()) {
            for (WaterData waterData : hMap.values()) {
                if (waterData.getId() == dataSerialNumber) {
                    result = waterData;
                    return result;
                }
                return null;
            }
        }
        return result;
    }
}
