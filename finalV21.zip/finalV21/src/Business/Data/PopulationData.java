/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Data;

import static java.lang.Math.abs;

/**
 *
 * @author Lig37
 */
public class PopulationData {
   
    private int id;
    private static int count;
    
    private String createYear;//keep track which day/time did the data collected 
    private String createMonth;
    
    private String yearMonth = createYear+"/"+createMonth;
    // carrying capacity
    //I = P ∙ A ∙ T
    //where:
    //I is the impact on the environment resulting from consumption
    //P is the population number
    //A is the consumption per capita (affluence)
    //T is the technology factor
    private int populationNumber;//P
    private int consumptionPerCapita;//A
    private int technologyFactor;//T
//    private int I = populationNumber * consumptionPerCapita*technologyFactor;;//impactOnEvironmentResultingFromConsumption
    
    
    private double HDI;//Human Development Index=3√LEI . EI . II 
    //no need setter for HDI
    private int lifeExpactancy;
//    private double lifeExceptencyIndex = (lifeExpactancy-20)/(85-20);//LEI
    //no need setter for LEI
    
    private int meanYearsOfSchooling;
//    private double meanYearsOfSchoolingIndex = meanYearsOfSchooling/15;//MYS; 15  is the projected maximum;
    //no need setter for MYS
    private int expectedYearsOfSchooling;
//    private double expectedYearsOfSchoolingIndex = //EYS;18 equivalent to achieving a master's degree in most countries
//    ////no need setter for EYS
//    private double educationIndex = () ;//EI
    //no need setter for EI
    private double incomeIndex;//II
    
    
    public int getI() {
        return populationNumber * consumptionPerCapita*technologyFactor;
    }
    
    public double getLifeExceptencyIndex() {
       return Math.round(((lifeExpactancy-20)/(85.0-20.0))* 100.0) / 100.0;
    }
    public double getEducationIndex() {
       return Math.round(((meanYearsOfSchooling/15.0+expectedYearsOfSchooling/18.0))* 100.0) / 100.0;
    }
    public double getMeanYearsOfSchoolingIndex() {
       return Math.round(((meanYearsOfSchooling/15.0))* 100.0) / 100.0;
    }
    public int getExpectedYearsOfSchooling() {
       return expectedYearsOfSchooling;
    }
    public double getExpectedYearsOfSchoolingIndex() {
       return Math.round((expectedYearsOfSchooling/18.0)* 100.0) / 100.0;
    }
 
    public double getHDI(){
        double number = Math.pow(getLifeExceptencyIndex(), 1/3)*(getEducationIndex())*(getMeanYearsOfSchoolingIndex());
        return Math.round(number* 100.0) / 100.0;
    }
  
     public String getYearMonth(){
    return createYear+"/"+createMonth;
    }
    
    public PopulationData(){
        id = count++;
    } 
    
    public String getCreateYear() {
        return createYear;
    }
    public void setCreateYear(String createYear) {
        this.createYear = createYear;
    }
    public String getCreateMonth() {
        return createMonth;
    }
    public void setCreateMonth(String createMonth) {
        this.createMonth = createMonth;
    }
    public int getPopulationNumber() {
        return populationNumber;
    }
    public void setPopulationNumber(int populationNumber) {
        this.populationNumber = populationNumber;
    }
    public int getConsumptionPerCapita() {
        return consumptionPerCapita;
    }
//    public String getYearMonth() {
//        return yearMonth;
//    }
    public void setYearMonth(String yearMonth) {
        this.yearMonth = yearMonth;
    }
    public void setConsumptionPerCapita(int consumptionPerCapita) {
        this.consumptionPerCapita = consumptionPerCapita;
    }
    public int getTechnologyFactor() {
        return technologyFactor;
    }
    public void setTechnologyFactor(int technologyFactor) {
        this.technologyFactor = technologyFactor;
    }
    public double getIncomeIndex() {
        return incomeIndex;
    }
    public void setIncomeIndex(double incomeIndex) {
        this.incomeIndex = incomeIndex;
    }
    public int getLifeExpactancy() {
        return lifeExpactancy;
    }
    public void setLifeExpactancy(int lifeExpactancy) {
        this.lifeExpactancy = lifeExpactancy;
    }
    public int getMeanYearsOfSchooling() {
        return meanYearsOfSchooling;
    }
  
    public void setMeanYearsOfSchooling(int meanYearsOfSchooling) {
        this.meanYearsOfSchooling = meanYearsOfSchooling;
    }
    public void setExpectedYearsOfSchooling(int expectedYearsOfSchooling) {
        this.expectedYearsOfSchooling = expectedYearsOfSchooling;
    }
    
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    
    public String evaluateHDI(double HDI){
        String HDIrank = null;
        if(HDI >= 0.8){HDIrank = "High";}
        else if(HDI< 0.8 && HDI >= 0.65){HDIrank = "Median High";}
        else if(HDI< 0.65 && HDI >= 0.50){HDIrank = "Average";}
        else if(HDI >= 0.35 && HDI < 0.50){HDIrank = "Median Low";}
        else if(HDI < 0.35){HDIrank = "Low";}
        else HDIrank = "Not available";
        return HDIrank;
    }
    
    public String evaluateLifeExpectancy(int lifeExpactancy){
        int x = lifeExpactancy - 71;//71 is the average world life span;
        String evalueateLifeExpectancy = null;
        String compareResult = null;
        if (x<0){
        compareResult = "shorter than";
        evalueateLifeExpectancy = "This city's lifeExpactancy is" + abs(x)+ "years"+ compareResult+"the world's average";
        }
        else if (x>0){
        compareResult = "longer than";
        evalueateLifeExpectancy = "This city's lifeExpactancy is" + abs(x)+ "years"+ compareResult+"the world's average";
        }
        else if (x == 0){
        evalueateLifeExpectancy = "This city's lifeExpactancy is equal to the world's average, which is 71 years"; 
        }
        return evalueateLifeExpectancy;
       
    }
    
    
    public String evaluateEducationIndex(double educationIndex) {
        String EIrank = null;
        if (educationIndex >= 0.8) {
            EIrank = "High";
        } else if (educationIndex < 0.8 && educationIndex >= 0.65) {
            EIrank = "Median High";
        } else if (educationIndex < 0.65 && educationIndex >= 0.50) {
            EIrank = "Average";
        } else if (educationIndex >= 0.35 && educationIndex < 0.50) {
            EIrank = "Median Low";
        } else if (educationIndex < 0.35) {
            EIrank = "Low";
        }
        else {
            EIrank = "Not available";
        }
        return EIrank;
    }
    
    
    @Override
    public String toString(){
        return createYear+"/"+createMonth;
    }
}
