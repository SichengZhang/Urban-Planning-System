/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Data;


/**
 *
 * @author Lig37
 */
public class HousingData {
  
   
   private int id;
   private static int count;
    
   private String createYear;//keep track which day/time did the data collected 
   private String createMonth;
   
   private String yearMonth = createYear+"/"+createMonth;
   
   private int noticesOfForeclousre;
   private int salesVolume;
   private int medianSalesPricePerUnit;
   private double indexOfHousingPriceAppreciation;
   private int unitsAuthorized;//UnitsAuthorizedByNewResidentialBuildingPermits;

   public HousingData(){
        id = count++;
    } 

    public String getCreateYear() {
        return createYear;
    }

    public void setCreateYear(String createYear) {
        this.createYear = createYear;
    }

    public String getCreateMonth() {
        return createMonth;
    }

    public void setCreateMonth(String createMonth) {
        this.createMonth = createMonth;
    }


    public int getNoticesOfForeclousre() {
        return noticesOfForeclousre;
    }

    public void setNoticesOfForeclousre(int noticesOfForeclousre) {
        this.noticesOfForeclousre = noticesOfForeclousre;
    }

    public int getSalesVolume() {
        return salesVolume;
    }

    public void setSalesVolume(int salesVolume) {
        this.salesVolume = salesVolume;
    }

    public int getMedianSalesPricePerUnit() {
        return medianSalesPricePerUnit;
    }

    public void setMedianSalesPricePerUnit(int medianSalesPricePerUnit) {
        this.medianSalesPricePerUnit = medianSalesPricePerUnit;
    }

    public double getIndexOfHousingPriceAppreciation() {
        return indexOfHousingPriceAppreciation;
    }

    public void setIndexOfHousingPriceAppreciation(double indexOfHousingPriceAppreciation) {
        this.indexOfHousingPriceAppreciation = indexOfHousingPriceAppreciation;
    }

    public int getUnitsAuthorized() {
        return unitsAuthorized;
    }

    public void setUnitsAuthorized(int unitsAuthorized) {
        this.unitsAuthorized = unitsAuthorized;
    }

    public String getYearMonth() {
        return createYear +"/" + createMonth;
    }

    public void setYearMonth(String yearMonth) {
        this.yearMonth = yearMonth;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
    
    @Override
    public String toString(){
        return createYear+"/"+createMonth;
    }
    
   
}
