/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Data;

import java.util.HashMap;

/**
 *
 * @author Lig37
 */
public class VegetationDataBase {
     private HashMap<String,HashMap<String,VegetationData>> vegetationHMap;
     
     
     public VegetationDataBase(){
         vegetationHMap = new HashMap();
     }

    public HashMap<String, HashMap<String, VegetationData>> getVegetationHMap() {
        return vegetationHMap;
    }

    public HashMap<String, VegetationData> getInnerHMap(String year){
        return vegetationHMap.get(year);
    }
    
    public void setVegetationHMap(HashMap<String, HashMap<String, VegetationData>> vegetationHMap) {
        this.vegetationHMap = vegetationHMap;
    }
     
//    public VegetationData addNewVegetationData(){
//        VegetationData vegetationData = new VegetationData();
//        for (String year : vegetationHMap.keySet()){
//            if (year.equals(vegetationData.getCreateYear())){
//                vegetationHMap.get(year).put(vegetationData.getCreateMonth(), vegetationData);
//            }
//            else {
//                HashMap<String, VegetationData> innerVegetationHMap = new HashMap();
//                vegetationHMap.put(vegetationData.getCreateYear(), innerVegetationHMap);
//                innerVegetationHMap.put(vegetationData.getCreateMonth(), vegetationData);
//            }
//        }
//        return vegetationData;
//}
       public void addNewVegetationData(VegetationData vegetationData){
       if (vegetationHMap.containsKey(vegetationData.getCreateYear())){
           vegetationHMap.get(vegetationData.getCreateYear()).put(vegetationData.getCreateMonth(), vegetationData);
       }
       else{
           HashMap<String, VegetationData> innerVegetationHMap = new HashMap();
           vegetationHMap.put(vegetationData.getCreateYear(), innerVegetationHMap);
           innerVegetationHMap.put(vegetationData.getCreateMonth(), vegetationData);
       }
   }

        public VegetationData searchBySerialNumber(int dataSerialNumber) {
        VegetationData result = null;
        result = new VegetationData();
        for (HashMap<String, VegetationData> hMap : vegetationHMap.values()) {
            for (VegetationData vegetationData : hMap.values()) {
                if (vegetationData.getId() == dataSerialNumber) {
                    result = vegetationData;
                    return result;
                }
                 return null;
            }
        }
       return result;
    }
}
