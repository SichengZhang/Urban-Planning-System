/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Data;

import java.util.HashMap;

/**
 *
 * @author Lig37
 */
public class HousingDataBase {
    
    private HashMap<String,HousingData> innerHMap;
     private HashMap<String,HashMap<String,HousingData>> housingHMap;
     
     
     public HousingDataBase(){
         housingHMap = new HashMap();
         innerHMap = new HashMap();
     }

    public HashMap<String, HashMap<String, HousingData>> getHousingHMap() {
        return housingHMap;
    }

    public HashMap<String, HousingData> getInnerHMap(String year){
        return housingHMap.get(year);
    }
    
    public void setHousingHMap(HashMap<String, HashMap<String, HousingData>> housingHMap) {
        this.housingHMap = housingHMap;
    }
     
     
    
    
//    public HousingData addNewHousingData(){
//        HousingData housingData = new HousingData();
//        for (String year : housingHMap.keySet()){
//            if (year.equals(housingData.getCreateYear())){
//                housingHMap.get(year).put(housingData.getCreateMonth(), housingData);
//            }
//            else {
//                HashMap<String, HousingData> innerHousingHMap = new HashMap();
//                housingHMap.put(housingData.getCreateYear(), innerHousingHMap);
//                innerHousingHMap.put(housingData.getCreateMonth(), housingData);
//            }
//        }
//    return  housingData;    
//}
    
    public void addNewHousingData(HousingData housingData){
       if (housingHMap.containsKey(housingData.getCreateYear())){
           housingHMap.get(housingData.getCreateYear()).put(housingData.getCreateMonth(), housingData);
       }
       else{
           HashMap<String, HousingData> innerHousingHMap = new HashMap();
           housingHMap.put(housingData.getCreateYear(), innerHousingHMap);
           innerHousingHMap.put(housingData.getCreateMonth(), housingData);
       }
   }
    

    public HousingData searchBySerialNumber(int dataSerialNumber) {
        HousingData result = null;
        result = new HousingData();
        for (HashMap<String, HousingData> hMap : housingHMap.values()) {
            for (HousingData housingData : hMap.values()) {
                if (housingData.getId() == dataSerialNumber) {
                    result = housingData;
                    return result;
                }
                 return null;
            }
        }
       return result;
    }
      

}