/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Data;

/**
 *
 * @author Sc Zhang
 */
public class DataAnalyzingReport {
    private double airQualitySatisfication;
    private double waterQualitySatisfication;
    private double vegetationStatusSatisfication;
    private double expectedLifespanAchievmentScale;
    private double educationLevelSatisfication;
    private double incomeSatisfication;
    private double residentialAreaPerCapitalSatisfication;
    
    public DataAnalyzingReport(){
        
    }
    
    private String planningAdvice;

    public double getAirQualitySatisfication() {
        return airQualitySatisfication;
    }

    public void setAirQualitySatisfication(double airQualitySatisfication) {
        this.airQualitySatisfication = airQualitySatisfication;
    }

    public double getWaterQualitySatisfication() {
        return waterQualitySatisfication;
    }

    public void setWaterQualitySatisfication(double waterQualitySatisfication) {
        this.waterQualitySatisfication = waterQualitySatisfication;
    }

    public double getVegetationStatusSatisfication() {
        return vegetationStatusSatisfication;
    }

    public void setVegetationStatusSatisfication(double vegetationStatusSatisfication) {
        this.vegetationStatusSatisfication = vegetationStatusSatisfication;
    }

    public double getExpectedLifespanAchievmentScale() {
        return expectedLifespanAchievmentScale;
    }

    public void setExpectedLifespanAchievmentScale(double expectedLifespanAchievmentScale) {
        this.expectedLifespanAchievmentScale = expectedLifespanAchievmentScale;
    }

    public double getEducationLevelSatisfication() {
        return educationLevelSatisfication;
    }

    public void setEducationLevelSatisfication(double educationLevelSatisfication) {
        this.educationLevelSatisfication = educationLevelSatisfication;
    }

    public double getIncomeSatisfication() {
        return incomeSatisfication;
    }

    public void setIncomeSatisfication(double incomeSatisfication) {
        this.incomeSatisfication = incomeSatisfication;
    }

    public double getResidentialAreaPerCapitalSatisfication() {
        return residentialAreaPerCapitalSatisfication;
    }

    public void setResidentialAreaPerCapitalSatisfication(double residentialAreaPerCapitalSatisfication) {
        this.residentialAreaPerCapitalSatisfication = residentialAreaPerCapitalSatisfication;
    }

    public String getPlanningAdvice() {
        return planningAdvice;
    }

    public void setPlanningAdvice(String planningAdvice) {
        this.planningAdvice = planningAdvice;
    }
    
}
