/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Data;

import java.io.File;

/**
 *
 * @author zhangshu
 */
public class DataPackage {
    private AirDataBase airDataBase;
    private HousingDataBase housingDataBase;
    private PopulationDataBase populationDataBase;
    private VegetationDataBase vegetationDataBase;
    private WaterDataBase waterDataBase;
    
    private File urbanPlanningSolutionFile;
    private DataAnalyzingReport AnalyzingReport;
    
    public DataPackage(){
        airDataBase = new AirDataBase();
        housingDataBase = new HousingDataBase();
        populationDataBase = new PopulationDataBase();
        vegetationDataBase = new VegetationDataBase();
        waterDataBase = new WaterDataBase();
        AnalyzingReport = new DataAnalyzingReport();
        urbanPlanningSolutionFile = null;
    }

    public DataAnalyzingReport getDataAnalyzingReport() {
        return AnalyzingReport;
    }

    public void setDataAnalyzingReport(DataAnalyzingReport AnalyzingReport) {
        this.AnalyzingReport = AnalyzingReport;
    }

 
    
    public AirDataBase getAirDataBase() {
        return airDataBase;
    }

    public void setAirDataBase(AirDataBase airDataBase) {
        this.airDataBase = airDataBase;
    }

    public HousingDataBase getHousingDataBase() {
        return housingDataBase;
    }

    public void setHousingDataBase(HousingDataBase housingDataBase) {
        this.housingDataBase = housingDataBase;
    }

    public PopulationDataBase getPopulationDataBase() {
        return populationDataBase;
    }

    public void setPopulationDataBase(PopulationDataBase populationDataBase) {
        this.populationDataBase = populationDataBase;
    }

    public VegetationDataBase getVegetationDataBase() {
        return vegetationDataBase;
    }

    public void setVegetationDataBase(VegetationDataBase vegetationDataBase) {
        this.vegetationDataBase = vegetationDataBase;
    }

    public WaterDataBase getWaterDataBase() {
        return waterDataBase;
    }

    public void setWaterDataBase(WaterDataBase waterDataBase) {
        this.waterDataBase = waterDataBase;
    }

    public File getUrbanPlanningSolutionFile() {
        return urbanPlanningSolutionFile;
    }

    public void setUrbanPlanningSolutionFile(File urbanPlanningSolutionFile) {
        this.urbanPlanningSolutionFile = urbanPlanningSolutionFile;
    }
    
    
}
