/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Data;

import java.util.Date;

/**
 *
 * @author Lig37
 */
public class WaterData {
   private int id;
   private static int count;
   private double bod5;
   
    
   private double pH;
   private double turbidity;
   private double temperature;
   private double suspendedSolids;
   private double dissolvedOxygen;
   
   private String createYear;
   private String createMonth;
   
   private String yearMonth = createYear+"/"+createMonth;

   public WaterData(){
   id = count++;
   }
   
    public double getpH() {
        return pH;
    }

    public void setpH(double pH) {
        this.pH = pH;
    }

    public double getTurbidity() {
        return turbidity;
    }

    public void setTurbidity(double turbidity) {
        this.turbidity = turbidity;
    }

    public double getTemperature() {
        return temperature;
    }

    public void setTemperature(double temperature) {
        this.temperature = temperature;
    }

    public double getSuspendedSolids() {
        return suspendedSolids;
    }

    public void setSuspendedSolids(double suspendedSolids) {
        this.suspendedSolids = suspendedSolids;
    }

    public double getDissolvedOxygen() {
        return dissolvedOxygen;
    }

    public void setDissolvedOxygen(double dissolvedOxygen) {
        this.dissolvedOxygen = dissolvedOxygen;
    }

    public String getCreateYear() {
        return createYear;
    }

    public void setCreateYear(String createYear) {
        this.createYear = createYear;
    }

    public String getCreateMonth() {
        return createMonth;
    }

    public void setCreateMonth(String createMonth) {
        this.createMonth = createMonth;
    }

    public String getYearMonth() {
        return yearMonth;
    }

    public void setYearMonth(String yearMonth) {
        this.yearMonth = yearMonth;
    }

    public int getId() {
        return id;
    }

    public double getBod5() {
        return bod5;
    }

    public void setBod5(double bod5) {
        this.bod5 = bod5;
    }

    
    
    @Override
    public String toString(){
        return createYear+"/"+createMonth;
    }
   


}
