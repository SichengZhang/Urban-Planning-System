/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Data;

import java.util.HashMap;

/**
 *
 * @author Lig37
 */
public class AirDataBase {
    private HashMap<String,HashMap<String,AirData>> airHMap;
     
     
     public AirDataBase(){
         airHMap = new HashMap();
     }

    public HashMap<String, HashMap<String, AirData>> getAirHMap() {
        return airHMap;
    }

    public HashMap<String, AirData> getInnerHMap(String year){
        return airHMap.get(year);
    }
    
    public void setAirHMap(HashMap<String, HashMap<String, AirData>> airHMap) {
        this.airHMap = airHMap;
    }
     
     
    
    
    public void addNewAirData(AirData airData){
    if (airHMap.keySet().contains(airData.getCreateYear())) {
            airHMap.get(airData.getCreateYear()).put(airData.getCreateMonth(), airData);
        } else {
            HashMap<String, AirData> innerAirHMap = new HashMap();
            airHMap.put(airData.getCreateYear(), innerAirHMap);
            innerAirHMap.put(airData.getCreateMonth(), airData);
        }
    }
  
    
    
    public AirData searchBySerialNumber(int dataSerialNumber) {
        AirData result = null;
        result = new AirData();
        for (HashMap<String, AirData> hMap : airHMap.values()) {
            for (AirData airData : hMap.values()) {
                if (airData.getId() == dataSerialNumber) {
                    result = airData;
                    return result;
                }
                return null;
            }
        }
        return result;
    }
}
