/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Data;



/**
 *
 * @author Lig37
 */
public class VegetationData {
    
    private int id;
    private static int count;
    
    private String yearMonth;
    private String createYear;//keep track which day/time did the data collected 
    private String createMonth;
//    private String yearMonth = createYear+"/"+createMonth;
   // rate of change of forest cover:
   //deforestation rate: r=(1/(t2−t1))×ln(A2/A1)
//    private int t1;//t1
//    private int t2;//t2
//    private double areaInT1;//A1
//    private double areaInT2;//A2
    private double forestArea;
 
    private double greenArea;
    private double totalArea;
//    private double greenRatio = greenArea/totalArea;
    
    //Open space ratio (OSR)= 
    //total amount of commonly-owned open space on the residential parcel proposed for development/  total area of the entire parcel proposed for development
    private double OpenSpaceOnRedidential;
    private double totalAreaOfEntireParcel;//LSR will use this as well
//    private double osr = OpenSpaceOnRedidential/totalAreaOfEntireParcel;
    //Landscape Surface Ratio (LSR)=
    //the total amount of landscaped and open space area on a nonresidential parcel proposed for development / entire area of the parcel proposed for development
    private double openSpaceOnNonresidental;
//    private double lsr = openSpaceOnNonresidental/totalAreaOfEntireParcel;
    public String getYearMonth(){
    return createYear+"/"+createMonth;
    }

    public void setYearMonth(String yearMonth) {
        this.yearMonth = yearMonth;
    }
    
    public double getGreenRatio() {
        return Math.round((greenArea/totalArea) * 100.0) / 100.0;
    }
    public double getOsr() {
       //Math.round((71+27.6 * random.nextGaussian()) * 100.0) / 100.0
        return Math.round((OpenSpaceOnRedidential/totalAreaOfEntireParcel) * 100.0) / 100.0;
    }
    public double getLsr() {
        return Math.round((openSpaceOnNonresidental/totalAreaOfEntireParcel) * 100.0) / 100.0;
    }
    public VegetationData(){
        id = count++;
    } 
    
    public double getGreenArea() {
        return greenArea;
    }
    public void setGreenArea(double greenArea) {
        this.greenArea = greenArea;
    }
    public double getTotalArea() {
        return totalArea;
    }
    public void setTotalArea(double totalArea) {
        this.totalArea = totalArea;
    }
    public double getOpenSpaceOnRedidential() {
        return OpenSpaceOnRedidential;
    }
    public void setOpenSpaceOnRedidential(double OpenSpaceOnRedidential) {
        this.OpenSpaceOnRedidential = OpenSpaceOnRedidential;
    }
    public double getTotalAreaOfEntireParcel() {
        return totalAreaOfEntireParcel;
    }
    public void setTotalAreaOfEntireParcel(double totalAreaOfEntireParcel) {
        this.totalAreaOfEntireParcel = totalAreaOfEntireParcel;
    }
    public double getOpenSpaceOnNonresidental() {
        return openSpaceOnNonresidental;
    }
    public void setOpenSpaceOnNonresidental(double openSpaceOnNonresidental) {
        this.openSpaceOnNonresidental = openSpaceOnNonresidental;
    }
    public String getCreateYear() {
        return createYear;
    }
    public void setCreateYear(String createYear) {
        this.createYear = createYear;
    }
    public String getCreateMonth() {
        return createMonth;
    }
    public void setCreateMonth(String createMonth) {
        this.createMonth = createMonth;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public double getForestArea() {
        return forestArea;
    }
    public void setForestArea(double forestArea) {
        this.forestArea = forestArea;
    }
    
    
    
 
    @Override
    public String toString(){
        return createYear+"/"+createMonth;
    }
    
}
