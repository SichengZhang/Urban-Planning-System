/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Data;


/**
 *
 * @author Lig37
 */
public class AirData {
   
    private int id;
    private static int count;
    private double pmConcentration;//ranging from 0 to 500
    private double so2Concentration;//ranging from 0 to 2620
    private double coConcentration;//ranging from 0 to 60
    private double aqi1;//pm
    private double aqi2;//so2
    private double aqi3;//co
    private double aqi;
    private String airQuality;

    private String createYear;
    private String createMonth;
    private String yearMonth = createYear+"/"+createMonth;
    
    private double fossilFuel;//as a factor，raging from 2000 to 4000 kt (city level)
    
    public AirData(){
        id = count++;
        
        
        
        
       
    }

    public double getPmConcentration() {
        return pmConcentration;
    }

    public void setPmConcentration(double pmConcentration) {
        this.pmConcentration = pmConcentration;
    }

    public double getSo2Concentration() {
        return so2Concentration;
    }

    public void setSo2Concentration(double so2Concentration) {
        this.so2Concentration = so2Concentration;
    }

    public double getCoConcentration() {
        return coConcentration;
    }

    public void setCoConcentration(double coConcentration) {
        this.coConcentration = coConcentration;
    }

    public double getAqi1() {
        return aqi1 = calculateAqi1(pmConcentration);
    }

    public double getAqi2() {
        return aqi2 = calculateAqi2(so2Concentration);
    }

    public double getAqi3() {
        return aqi3 = calculateAqi3(coConcentration);
    }

    public double getAqi() {
        return aqi = Math.max(getAqi1(), Math.max(getAqi2(), getAqi3()));
    }

    public String getAirQuality() {
        return airQuality = toAirQuality(aqi);
    }

    public String getCreateYear() {
        return createYear;
    }

    public void setCreateYear(String createYear) {
        this.createYear = createYear;
    }

    public String getCreateMonth() {
        return createMonth;
    }

    public void setCreateMonth(String createMonth) {
        this.createMonth = createMonth;
    }

    public void setAqi1(double aqi1) {
        this.aqi1 = aqi1;
    }

    public void setAqi2(double aqi2) {
        this.aqi2 = aqi2;
    }

    public void setAqi3(double aqi3) {
        this.aqi3 = aqi3;
    }

    public void setAqi(double aqi) {
        this.aqi = aqi;
    }

    public void setAirQuality(String airQuality) {
        this.airQuality = airQuality;
    }

    public int getId() {
        return id;
    }

    public String getYearMonth() {
        return yearMonth = createYear+"/"+createMonth;
    }

    public void setYearMonth(String yearMonth) {
        this.yearMonth = yearMonth;
    }

    public double getFossilFuel() {
        return fossilFuel;
    }

    public void setFossilFuel(double fossilFuel) {
        this.fossilFuel = fossilFuel;
    }
    
    
    

    
    public double calculateAqi1(double pmConcentration){
    
        if(pmConcentration >= 0 && pmConcentration < 35){
            aqi1 = 50/35*pmConcentration;
        }
        else if(pmConcentration >= 35 && pmConcentration < 75){
            aqi1= (100-50)/(75-35)*(pmConcentration-35)+50;
        }
        else if(pmConcentration >= 75 && pmConcentration < 115){
            aqi1= (150-100)/(115-75)*(pmConcentration-75)+100;
        }
        else if(pmConcentration >= 115 && pmConcentration < 150){
            aqi1= (200-150)/(150-115)*(pmConcentration-115)+150;
        }
        else if(pmConcentration >= 150 && pmConcentration < 250){
            aqi1= (300-200)/(250-150)*(pmConcentration-150)+200;
        }
        else if(pmConcentration >= 250 && pmConcentration < 350){
            aqi1= (400-300)/(350-250)*(pmConcentration-250)+300;
        }
        else{
            aqi1= (500-400)/(500-350)*(pmConcentration-350)+400;
        } 
        return aqi1;
    }
    
    public double calculateAqi2(double so2Concentration){
    
        if(so2Concentration >= 0 && so2Concentration < 50){
            aqi2 = so2Concentration;
        }
        else if(so2Concentration >= 50 && so2Concentration < 150){
            aqi2= (100-50)/(150-50)*(so2Concentration-50)+50;
        }
        else if(so2Concentration >= 150 && so2Concentration < 475){
            aqi2= (150-100)/(475-150)*(so2Concentration-150)+100;
        }
        else if(so2Concentration >= 475 && so2Concentration < 800){
            aqi2= (200-150)/(800-475)*(so2Concentration-475)+150;
        }
        else if(so2Concentration >= 800 && so2Concentration < 1600){
            aqi2= (300-200)/(1600-800)*(so2Concentration-800)+200;
        }
        else if(so2Concentration >= 1600 && so2Concentration < 2100){
            aqi2= (400-300)/(2100-1600)*(so2Concentration-1600)+300;
        }
        else{
            aqi2= (500-400)/(2620-2100)*(so2Concentration-2100)+400;
        } 
        return aqi2;
    }
    
    public double calculateAqi3(double coConcentration){

        if(coConcentration >= 0 && coConcentration < 2){
            aqi3 = 25*coConcentration;
        }
        else if(coConcentration >= 2 && coConcentration < 4){
            aqi3= (100-50)/(4-2)*(coConcentration-2)+50;
        }
        else if(coConcentration >= 4 && coConcentration < 14){
            aqi3= (150-100)/(14-4)*(coConcentration-4)+100;
        }
        else if(coConcentration >= 14 && coConcentration < 24){
            aqi3= (200-150)/(24-14)*(coConcentration-14)+150;
        }
        else if(coConcentration >= 24 && coConcentration < 36){
            aqi3= (300-200)/(36-24)*(coConcentration-24)+200;
        }
        else if(coConcentration >= 36 && coConcentration < 48){
            aqi3= (400-300)/(48-36)*(coConcentration-36)+300;
        }
        else{
            aqi3= (500-400)/(60-48)*(coConcentration-60)+400;
        } 
        return aqi3;
    }
    
    public String toAirQuality(double aqi){
        
        if(aqi >= 0 && aqi <= 50){
            airQuality = "Good";
        }
        
        else if(aqi > 50 && aqi <= 100){
            airQuality = "Medium";
        }
        
        else if(aqi > 100 && aqi <= 150){
            airQuality = "Unhealthy for sensitive people";
        }
        
        else if(aqi > 150 && aqi <= 200){
            airQuality = "Unhealthy";
        }
        
        else if(aqi > 200 && aqi <= 300){
            airQuality = "extra unhealthy";
        }
        
        else{
            airQuality = "Poisonous";
        }
        
        return airQuality;
    }
    
    @Override
    public String toString(){
        return createYear+"/"+createMonth;
    }
    
}