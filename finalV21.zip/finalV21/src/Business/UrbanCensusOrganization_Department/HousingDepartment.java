/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.UrbanCensusOrganization_Department;

import Business.Data.HousingData;
import Business.Data.HousingDataBase;
import Business.Department.Department;
import Business.Role.Role;
import Business.UrbanCensusOrganization_Role.HousingManagerRole;

/**
 *
 * @author Sc Zhang
 */
public class HousingDepartment extends Department{
    private HousingData housingData;
    private HousingDataBase housingDataBase;

    public HousingData getHousingData() {
        return housingData;
    }

    public void setHousingData(HousingData housingData) {
        this.housingData = housingData;
    }

    public HousingDataBase getHousingDataBase() {
        return housingDataBase;
    }

    public void setHousingDataBase(HousingDataBase housingDataBase) {
        this.housingDataBase = housingDataBase;
    }
    
    public HousingDepartment(){
        super(DepartmentType.HousingDepartment);
    }

    @Override
    public Role getSupportedRole() {
        return new HousingManagerRole();
    }

    
    @Override
    public String toString() {
        return super.getName();
    }
    
    
}
