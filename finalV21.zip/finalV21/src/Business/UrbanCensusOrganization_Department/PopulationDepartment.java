/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.UrbanCensusOrganization_Department;

import Business.Data.PopulationData;
import Business.Data.PopulationDataBase;
import Business.Department.Department;
import Business.Role.Role;
import Business.UrbanCensusOrganization_Role.PopulationInspectorRole;

/**
 *
 * @author Sc Zhang
 */
public class PopulationDepartment extends Department{
    private PopulationData populationData;
    private PopulationDataBase populationDataBase;

    public PopulationData getPopulationData() {
        return populationData;
    }

    public void setPopulationData(PopulationData populationData) {
        this.populationData = populationData;
    }

    public PopulationDataBase getPopulationDataBase() {
        return populationDataBase;
    }

    public void setPopulationDataBase(PopulationDataBase populationDataBase) {
        this.populationDataBase = populationDataBase;
    }
    
    public PopulationDepartment(){
        super(DepartmentType.PopulationDepartment);
    }

    @Override
    public Role getSupportedRole() {
        return new PopulationInspectorRole();
    }

    @Override
    public String toString() {
        return super.getName();
    }
}
