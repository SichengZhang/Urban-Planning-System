/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.UrbanEnvironmentalOrganization_Department;

import Business.Data.AirData;
import Business.Data.AirDataBase;
import Business.Department.Department;
import Business.Role.Role;
import Business.UrbanEnvironmentalOrganization_Role.AirQualityInspectorRole;

/**
 *
 * @author Sc Zhang
 */
public class AirQualityDepartment extends Department{
    private AirData airData;
    private AirDataBase airDataBase;

    public AirData getAirData() {
        return airData;
    }

    public void setAirData(AirData airData) {
        this.airData = airData;
    }

    public AirDataBase getAirDataBase() {
        return airDataBase;
    }

    public void setAirDataBase(AirDataBase airDataBase) {
        this.airDataBase = airDataBase;
    }
    
    public AirQualityDepartment(){
        super(DepartmentType.AirQualityDepartment);
    }

    @Override
    public Role getSupportedRole() {
        return new AirQualityInspectorRole();
    }

    @Override
    public String toString() {
        return super.getName();
    }
    
}
