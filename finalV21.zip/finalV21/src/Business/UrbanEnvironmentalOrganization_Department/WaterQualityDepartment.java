/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.UrbanEnvironmentalOrganization_Department;

import Business.Data.WaterData;
import Business.Data.WaterDataBase;
import Business.Department.Department;
import Business.Role.Role;
import Business.UrbanEnvironmentalOrganization_Role.WaterQualityInspectorRole;

/**
 *
 * @author Sc Zhang
 */
public class WaterQualityDepartment extends Department{
    private WaterData waterData;
    private WaterDataBase waterDataBase;

    public WaterData getWaterData() {
        return waterData;
    }

    public void setWaterData(WaterData waterData) {
        this.waterData = waterData;
    }

    public WaterDataBase getWaterDataBase() {
        return waterDataBase;
    }

    public void setWaterDataBase(WaterDataBase waterDataBase) {
        this.waterDataBase = waterDataBase;
    }
    
    public WaterQualityDepartment(){
        super(DepartmentType.WaterQualityDepartment);
    }

    @Override
    public Role getSupportedRole() {
        return new WaterQualityInspectorRole();
    }

    @Override
    public String toString() {
        return super.getName();
    }
    
}
