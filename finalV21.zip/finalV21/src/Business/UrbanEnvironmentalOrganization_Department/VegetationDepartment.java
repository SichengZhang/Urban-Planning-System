/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.UrbanEnvironmentalOrganization_Department;

import Business.Data.VegetationData;
import Business.Data.VegetationDataBase;
import Business.Data.WaterData;
import Business.Data.WaterDataBase;
import Business.Department.Department;
import Business.Role.Role;
import Business.UrbanEnvironmentalOrganization_Role.VegetationInspectorRole;

/**
 *
 * @author Sc Zhang
 */
public class VegetationDepartment extends Department{
    private VegetationData vegetationData;
    private VegetationDataBase vegetationDataBase;

    public VegetationData getVegetationData() {
        return vegetationData;
    }

    public void setVegetationData(VegetationData vegetationData) {
        this.vegetationData = vegetationData;
    }

    public VegetationDataBase getVegetationDataBase() {
        return vegetationDataBase;
    }

    public void setVegetationDataBase(VegetationDataBase vegetationDataBase) {
        this.vegetationDataBase = vegetationDataBase;
    }
    
    public VegetationDepartment(){
        super(DepartmentType.VegetationDepartment);
    }

    @Override
    public Role getSupportedRole() {
        return new VegetationInspectorRole();
    }

    @Override
    public String toString() {
        return super.getName();
    }
}
