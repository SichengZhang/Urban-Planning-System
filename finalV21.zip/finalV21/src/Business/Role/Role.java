/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Role;

/**
 *
 * @author Sc Zhang
 */
public abstract class Role {
    private RoleType roleType;
    
    public Role(RoleType roleType){
        this.roleType = roleType;
    }
    
    public enum RoleType{
        OrganizationAdmin("Organization Admin"),
        
        HousingManagerRole("Housing Manager Role"),
        PopulationInspectorRole("Population Inspector Role"),
        AirQualityInspectorRole("Air Quality Inspector Role"),
        WaterQualityInspectorRole("Water Quality Inspector Role"),
        VegetationQualityInspectorRole("Vegetation Quality Inspector Role"),
        DataAnalystRole("Data Analyst Role"),
        StrategicConsultanRole("Strategic Consultan Role"),
        
        SystemAdmin("System Admin");
        
        private String value;
        
        
        
        private RoleType(String value){
            this.value = value;
        }

        public String getValue() {
            return value;
        }

        @Override
        public String toString() {
            return value;
        }
    }

    @Override
    public String toString() {
        return String.valueOf(roleType);
    }
    
    
}
