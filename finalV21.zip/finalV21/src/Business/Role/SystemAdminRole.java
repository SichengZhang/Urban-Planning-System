/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Role;

/**
 *
 * @author Sc Zhang
 */
public class SystemAdminRole extends Role{
    
    public SystemAdminRole(RoleType roleType) {
        super(RoleType.SystemAdmin);
    }
    
}
