/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Role;

/**
 *
 * @author Sc Zhang
 */
public class OrganizationAdminRole extends Role{

    public OrganizationAdminRole() {
        super(RoleType.OrganizationAdmin);
    }
    
    public enum BelongingOrganization{
        UrbanCensusOrganization("Urban Census Organization"),
        UrbanPlanningOrganization("Urban Planning Organization"),
        UrbanEnvironmentalOrganization("Urban Environmental Organization");
        
        private String value;
        private BelongingOrganization(String value){
            this.value = value;
        }

        public String getValue() {
            return value;
        }

        @Override
        public String toString() {
            return value;
        }
    }
}
