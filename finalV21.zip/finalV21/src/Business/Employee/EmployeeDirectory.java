/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Employee;

import java.util.ArrayList;

/**
 *
 * @author Sc Zhang
 */
public class EmployeeDirectory {
    
    private ArrayList<Employee> personDirectory;
    
    public EmployeeDirectory(){
        personDirectory = new ArrayList();
    }

    public ArrayList<Employee> getPersonDirectory() {
        return personDirectory;
    }

    public void setPersonDirectory(ArrayList<Employee> personDirectory) {
        this.personDirectory = personDirectory;
    }
    
    public Employee createEmployee(String name){
        Employee employee = new Employee(name);
        personDirectory.add(employee);
        return employee;
    }
}
