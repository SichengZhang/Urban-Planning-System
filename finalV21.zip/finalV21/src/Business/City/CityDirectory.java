/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.City;

import Business.State.State;
import java.util.ArrayList;

/**
 *
 * @author Sc Zhang
 */
public class CityDirectory {
    
    private ArrayList<City> cityDirectory;

    public CityDirectory(){
        cityDirectory = new ArrayList();
    }

    public ArrayList<City> getCityDirectory() {
        return cityDirectory;
    }

    public void setCityDirectory(ArrayList<City> cityDirectory) {
        this.cityDirectory = cityDirectory;
    }
    
    
    
    public City createAndAddCity(String name){
        City city = new City();
        city.setName(name);
        cityDirectory.add(city);
        return city;
    }
}
