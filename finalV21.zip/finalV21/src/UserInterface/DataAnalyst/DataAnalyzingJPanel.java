/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UserInterface.DataAnalyst;

import Business.BasicMathematicMethods.BasicMathematicMethods;
import Business.Data.AirData;
import Business.Data.AirDataBase;
import Business.Data.DataPackage;
import Business.Data.HousingData;
import Business.Data.HousingDataBase;
import Business.Data.PopulationData;
import Business.Data.PopulationDataBase;
import Business.Data.VegetationData;
import Business.Data.VegetationDataBase;
import Business.Data.WaterData;
import Business.Data.WaterDataBase;
import Business.WorkQueue.WorkRequestCommon;
import java.awt.BasicStroke;
import java.awt.CardLayout;
import java.awt.Color;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;
import java.util.Set;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.renderer.category.LineAndShapeRenderer;
import org.jfree.data.category.DefaultCategoryDataset;

/**
 *
 * @author Sc Zhang
 */
public class DataAnalyzingJPanel extends javax.swing.JPanel {

    /**
     * Creates new form NewJPanel
     */
    private JPanel userProcessContainer;
    private WorkRequestCommon workRequestCommon;
    DataPackage dataPackage;
    double aqi = 0.0;
    double bod5;
    double vegetationStatus;
    double expectedLifeAchievementScale;
    double incomeSatisfication;
    double eduLevel;
    double housingSatification;
    
    
    public DataAnalyzingJPanel(JPanel userProcessContainer, WorkRequestCommon workRequestCommon) {
        initComponents();
        this.userProcessContainer = userProcessContainer;
        this.workRequestCommon = workRequestCommon;
        dataPackage = new DataPackage();
        populateTblDataDisplay();
        populatecmbFactorTypeAir();
        populatecmbFactorTypePop();
        populatecmbFactorTypeVeg();
        populatecmbFactorTypeWater();
    }
    
    public void populatecmbFactorTypePop() {
        cmbFactorTypePop.removeAllItems();
        cmbFactorTypePop.addItem("Life Expectancy Index");
        cmbFactorTypePop.addItem("Mean Years Of Schooling Index");
        cmbFactorTypePop.addItem("Income Index");
    }

    public void populatecmbFactorTypeVeg() {

        cmbFactorTypeVeg.removeAllItems();
        cmbFactorTypeVeg.addItem("Green Area Ratio");
        cmbFactorTypeVeg.addItem("Open space ratio");
        cmbFactorTypeVeg.addItem("Landscape Surface Ratio");
        cmbFactorTypeVeg.addItem("Forest Area");
    }

    public void populatecmbFactorTypeAir() {

        cmbFactorTypeAir.removeAllItems();
        cmbFactorTypeAir.addItem("SO2 Concentration");
        cmbFactorTypeAir.addItem("CO Concentration");
        cmbFactorTypeAir.addItem("PM2.5");
        
    }
    
    public void populatecmbFactorTypeWater() {

        cmbFactorTypeWater.removeAllItems();
        cmbFactorTypeWater.addItem("BOD5");
        cmbFactorTypeWater.addItem("PH");
        cmbFactorTypeWater.addItem("Turbidity");
        cmbFactorTypeWater.addItem("Temperature");
        cmbFactorTypeWater.addItem("Suspended Solids");
        cmbFactorTypeWater.addItem("Dissolved Oxygen");
        
    }

     
    private void populateTblPopulation(int iMean,double iSD,double iIncreamentalRatio,
                                        double leiMean,double leiSD,double leiIncreamentalRatio,
                                        double mysiMean,double mysiSD,double mysiIncreamentalRatio,
                                        double eysiMean,double eysiSD,double eysiIncreamentalRatio,
                                        double incomeIndexMean,double incomeIndexSD,double incomeIndexIncreamentalRatio){
     DefaultTableModel dtm = (DefaultTableModel) tblPopulation.getModel();
        dtm.setRowCount(0);
               Object[] row0 = new Object[4];
               row0[0] = "Population Number";
               row0[1] = iMean;
               row0[2] = iSD;
               row0[3] = iIncreamentalRatio;
               dtm.addRow(row0);
               
               Object[] row1 = new Object[4];
               row1[0] = "Life Exceptency Index";
               row1[1] = leiMean;
               row1[2] = leiSD;
               row1[3] = leiIncreamentalRatio;
               dtm.addRow(row1);
            
               Object[] row2 = new Object[4];
               row2[0] = "Mean Years Of Schooling Index";
               row2[1] = mysiMean;
               row2[2] = mysiSD;
               row2[3] = mysiIncreamentalRatio;
               dtm.addRow(row2);
               
               Object[] row3 = new Object[4];
               row3[0] = "Expected Years Of Schooling Index";
               row3[1] = eysiMean;
               row3[2] = eysiSD;
               row3[3] = eysiIncreamentalRatio;
               dtm.addRow(row3);
            
               Object[] row4 = new Object[4];
               row4[0] = "Income Index";
               row4[1] = incomeIndexMean;
               row4[2] = incomeIndexSD;
               row4[3] = incomeIndexIncreamentalRatio;
               dtm.addRow(row4);

          
        }
    
     private void populateTblVegetation(double greenRatioMean,double greenRatioSD,double greenRatioIncreamentalRatio,
             double osrMean,double osrSD,double osrIncreamentalRatio,
             double lsrMean,double lsrSD,double lsrIncreamentalRatio,
             double forestMean,double forestSD,double forestIncreamentalRatio){
     DefaultTableModel dtm = (DefaultTableModel) tblVegetation.getModel();
        dtm.setRowCount(0);
               Object[] row0 = new Object[4];
               row0[0] = "Green Area Ratio";
               row0[1] = greenRatioMean;
               row0[2] = greenRatioSD;
               row0[3] = greenRatioIncreamentalRatio;
               dtm.addRow(row0);
               
               Object[] row1 = new Object[4];
               row1[0] = "Open space ratio (OSR)";
               row1[1] = osrMean;
               row1[2] = osrSD;
               row1[3] = osrIncreamentalRatio;
               dtm.addRow(row1);
            
               Object[] row2 = new Object[4];
               row2[0] = "Landscape Surface Ratio (LSR)";
               row2[1] = lsrMean;
               row2[2] = lsrSD;
               row2[3] = lsrIncreamentalRatio;
               dtm.addRow(row2);
               
               Object[] row3 = new Object[4];
               row3[0] = "Forest Area";
               row3[1] = forestMean;
               row3[2] = forestSD;
               row3[3] = forestIncreamentalRatio;
               dtm.addRow(row3);
     }
       private void populateTblAir(double pmMean,double pmSD,double pmIncreamentalRatio,double so2Mean,double so2SD,double so2IncreamentalRatio,double coMean,double coSD, double coIncreamentalRatio){
      DefaultTableModel dtm = (DefaultTableModel) tblAir.getModel();
       dtm.setRowCount(0);
              Object[] row0 = new Object[4];
              row0[0] = "PM2.5 Concentration";
              row0[1] = pmMean;
              row0[2] = pmSD;
              row0[3] = pmIncreamentalRatio;
              dtm.addRow(row0);
              
              Object[] row1 = new Object[4];
              row1[0] = "SO2 Concentration";
              row1[1] = so2Mean;
              row1[2] = so2SD;
              row1[3] = so2IncreamentalRatio;
              dtm.addRow(row1);
           
              Object[] row2 = new Object[4];
              row2[0] = "CO Concentration";
              row2[1] = coMean;
              row2[2] = coSD;
              row2[3] = coIncreamentalRatio;
              dtm.addRow(row2);
    }
     private void populateTblHousing(
             int salseVolumeMean,double slaesVolumeSD,double salesVolumeIR,
             
             double indexOfHousingPriceAppreciationMean,double indexOfHousingPriceAppreciationSD,double indexOfHousingPriceAppreciationIR,
             int unitsAuthorizedMean,double unitsAuthorizedSD,double unitsAuthorizedIR){
     DefaultTableModel dtm = (DefaultTableModel) tblHousing.getModel();
        dtm.setRowCount(0);
               
               
               Object[] row1 = new Object[4];
               row1[0] = "Sales Volume";
               row1[1] = salseVolumeMean;
               row1[2] = slaesVolumeSD;
               row1[3] = salesVolumeIR;
               dtm.addRow(row1);
            
               
               Object[] row3 = new Object[4];
               row3[0] = "Index Of Housing Price Appreciation";
               row3[1] = indexOfHousingPriceAppreciationMean;
               row3[2] = indexOfHousingPriceAppreciationSD;
               row3[3] = indexOfHousingPriceAppreciationIR;
               dtm.addRow(row3);
               
               Object[] row4 = new Object[4];
               row4[0] = "units Authorized";
               row4[1] = unitsAuthorizedMean;
               row4[2] = unitsAuthorizedSD;
               row4[3] = unitsAuthorizedIR;
               dtm.addRow(row4);
     }
     
     
     
     
     private void populateTblWater(double bod5Mean, double bod5SD, double bod5IncreamentalRatio, double phMean, double phSD, double phIncreamentalRatio, double turbidityMean, double turbiditySD, double turbidityIncreamentalRatio, double temperatureMean, double temperatureSD, double temperatureIncreamentalRatio, double ssMean, double ssSD, double ssIncreamentalRatio , double doMean, double doSD, double doIncreamentalRatio){
     DefaultTableModel dtm = (DefaultTableModel) tblWater.getModel();
        dtm.setRowCount(0);
               Object[] row0 = new Object[4];
               row0[0] = "Biochemical Oxygen Demand (BOD)";
               row0[1] = bod5Mean;
               row0[2] = bod5SD;
               row0[3] = bod5IncreamentalRatio;
               dtm.addRow(row0);
               
               Object[] row1 = new Object[4];
               row1[0] = "PH";
               row1[1] = phMean;
               row1[2] = phSD;
               row1[3] = phIncreamentalRatio;
               dtm.addRow(row1);
            
               Object[] row2 = new Object[4];
               row2[0] = "Turbidity";
               row2[1] = turbidityMean;
               row2[2] = turbiditySD;
               row2[3] = turbidityIncreamentalRatio;
               dtm.addRow(row2);
               
               Object[] row3 = new Object[4];
               row3[0] = "Temperature";
               row3[1] = temperatureMean;
               row3[2] = temperatureSD;
               row3[3] = temperatureIncreamentalRatio;
               dtm.addRow(row3);
            
               Object[] row4 = new Object[4];
               row4[0] = "Suspended Solids";
               row4[1] = ssMean;
               row4[2] = ssSD;
               row4[3] = ssIncreamentalRatio;
               dtm.addRow(row4);
               
               Object[] row5 = new Object[4];
               row5[0] = "Dissolved Oxygen";
               row5[1] = doMean;
               row5[2] = doSD;
               row5[3] = doIncreamentalRatio;
               dtm.addRow(row5);
     }
     
    private void populateTblDataDisplay(){
        DefaultTableModel dtm = (DefaultTableModel) tblDataDisplay.getModel();
        dtm.setRowCount(0);
      
        for (HashMap<String, AirData> hMap : workRequestCommon.getDataPackage().getAirDataBase().getAirHMap().values()) {
            for (AirData airData : hMap.values()) {
               Object[] row = new Object[3];
               row[0] = airData;
               row[1] = airData.getId();
               row[2] = "Air Quality";
               dtm.addRow(row);
            }
        }
        
        for (HashMap<String, WaterData> hMap : workRequestCommon.getDataPackage().getWaterDataBase().getWaterHMap().values()) {
            for (WaterData waterData : hMap.values()) {
               Object[] row = new Object[3];
               row[0] = waterData;
               row[1] = waterData.getId();
               row[2] = "Water Quality";
               dtm.addRow(row);
            }
        }
        
        for (HashMap<String, VegetationData> hMap : workRequestCommon.getDataPackage().getVegetationDataBase().getVegetationHMap().values()) {
            for (VegetationData vegetationData : hMap.values()) {
               Object[] row = new Object[3];
               row[0] = vegetationData;
               row[1] = vegetationData.getId();
               row[2] = "Vegetation Data";
               dtm.addRow(row);
            }
        }
        
        for (HashMap<String, HousingData> hMap : workRequestCommon.getDataPackage().getHousingDataBase().getHousingHMap().values()) {
            for (HousingData housingData : hMap.values()) {
               Object[] row = new Object[3];
               row[0] = housingData;
               row[1] = housingData.getId();
               row[2] = "Housing Data";
               dtm.addRow(row);
            }
        }
        
        for (HashMap<String, PopulationData> hMap : workRequestCommon.getDataPackage().getPopulationDataBase().getPopulationHMap().values()) {
            for (PopulationData populationData : hMap.values()) {
               Object[] row = new Object[3];
               row[0] = populationData;
               row[1] = populationData.getId();
               row[2] = "Population Data";
               dtm.addRow(row);
            }
        }
        
    }
    
    private void populateTblDataInUse(DataPackage dataPackage){
        DefaultTableModel dtm=(DefaultTableModel)tblDataInUse.getModel();//DefaultTableModel-class
        dtm.setRowCount(0);
        for (HashMap<String, AirData> hMap : dataPackage.getAirDataBase().getAirHMap().values()) {
            for (AirData airData : hMap.values()) {
               Object[] row = new Object[3];
               row[0] = airData;
               row[1] = airData.getId();
               row[2] = "Air Quality";
               dtm.addRow(row);
            }
        }
        
        for (HashMap<String, WaterData> hMap : dataPackage.getWaterDataBase().getWaterHMap().values()) {
            for (WaterData waterData : hMap.values()) {
               Object[] row = new Object[3];
               row[0] = waterData;
               row[1] = waterData.getId();
               row[2] = "Water Quality";
               dtm.addRow(row);
            }
        }
        
        for (HashMap<String, VegetationData> hMap : dataPackage.getVegetationDataBase().getVegetationHMap().values()) {
            for (VegetationData vegetationData : hMap.values()) {
               Object[] row = new Object[3];
               row[0] = vegetationData;
               row[1] = vegetationData.getId();
               row[2] = "Vegetation Data";
               dtm.addRow(row);
            }
        }
        
        for (HashMap<String, HousingData> hMap : dataPackage.getHousingDataBase().getHousingHMap().values()) {
            for (HousingData housingData : hMap.values()) {
               Object[] row = new Object[3];
               row[0] = housingData;
               row[1] = housingData.getId();
               row[2] = "Housing Data";
               dtm.addRow(row);
            }
        }
        
        for (HashMap<String, PopulationData> hMap : dataPackage.getPopulationDataBase().getPopulationHMap().values()) {
            for (PopulationData populationData : hMap.values()) {
               Object[] row = new Object[3];
               row[0] = populationData;
               row[1] = populationData.getId();
               row[2] = "Population Data";
               dtm.addRow(row);
            }
        }
    }
     
    private void populateTblDataWithIssues(){
       DefaultTableModel dtm = (DefaultTableModel) tblDataIWithIssues.getModel();
        dtm.setRowCount(0);
        for (HashMap<String, AirData> hMap : workRequestCommon.getDataPackage().getAirDataBase().getAirHMap().values()) {
            for (AirData airData : hMap.values()) {
                double aqi = airData.getAqi();
                
               
                 if (aqi > 300 && aqi <= 400) {
                    Object[] row = new Object[5];
                    row[0] = airData;
                    row[1] = "Air Quality";
                    row[2] = "AQI";
                    row[3] = airData.getAqi();
                    row[4] = "extra unhealthy";
                    dtm.addRow(row); 
                } else if (aqi > 400) {
                    Object[] row = new Object[5];
                    row[0] = airData;
                    row[1] = "Air Quality";
                    row[2] = "AQI";
                    row[3] = airData.getAqi();
                    row[4] = "Poisonous";
                    dtm.addRow(row); 
                }
            }
        }
        
        for (HashMap<String, WaterData> hMap : workRequestCommon.getDataPackage().getWaterDataBase().getWaterHMap().values()) {
            for (WaterData waterData : hMap.values()) {
                double bod5 = waterData.getBod5();
                if(bod5>8 && bod5 <= 10){
                    Object[] row = new Object[5];
                    row[0] = waterData;
                    row[1] = "Water Quality";
                    row[2] = "BOD5";
                    row[3] = waterData.getBod5();
                    row[4] = "Severly polluted";
                    dtm.addRow(row);
                }
                else if(bod5>5 && bod5 <= 8){
                    Object[] row = new Object[5];
                    row[0] = waterData;
                    row[1] = "Water Quality";
                    row[2] = "BOD5";
                    row[3] = waterData.getBod5();
                    row[4] = "Slightly polluted";
                    dtm.addRow(row);
                }
            }
        }
        
        for (HashMap<String, VegetationData> hMap : workRequestCommon.getDataPackage().getVegetationDataBase().getVegetationHMap().values()) {
            for (VegetationData vegetationData : hMap.values()) {
                double greenRatio = vegetationData.getGreenRatio();
               if (greenRatio > 0 && greenRatio <= 0.1) {
                    Object[] row = new Object[5];
                    row[0] = vegetationData;
                    row[1] = "Vegetation";
                    row[2] = "Green Ratio";
                    row[3] = vegetationData.getGreenRatio();
                    row[4] = "Very Poor Vegetation";
                    dtm.addRow(row); 
                } else if (greenRatio > 0.1 && greenRatio <= 0.2) {
                    Object[] row = new Object[5];
                    row[0] = vegetationData;
                    row[1] = "Vegetation";
                    row[2] = "Green Ratio";
                    row[3] = vegetationData.getGreenRatio();
                    row[4] = "Poor Vegetation";
                    dtm.addRow(row); 
                } else if (greenRatio > 0.2 && greenRatio <= 0.3) {
                    Object[] row = new Object[5];
                    row[0] = vegetationData;
                    row[1] = "Vegetation";
                    row[2] = "Green Ratio";
                    row[3] = vegetationData.getGreenRatio();
                    row[4] = "Limited Vegetation";
                    dtm.addRow(row); 
                } 
            }
        }
        
        for (HashMap<String, HousingData> hMap : workRequestCommon.getDataPackage().getHousingDataBase().getHousingHMap().values()) {
            for (HousingData housingData : hMap.values()) {
                double IndexOfHousingPriceAppreciation = housingData.getIndexOfHousingPriceAppreciation();
                
                 if( IndexOfHousingPriceAppreciation < 0.35){
                    Object[] row = new Object[5];
                    row[0] = housingData;
                    row[1] = "Housing Data";
                    row[2] = "Housing Price Appreciation Per Month";
                    row[3] = housingData.getIndexOfHousingPriceAppreciation();
                    row[4] = "high";
                    dtm.addRow(row);
                }
            }
        }
        
        for (HashMap<String, PopulationData> hMap : workRequestCommon.getDataPackage().getPopulationDataBase().getPopulationHMap().values()) {
            for (PopulationData populationData : hMap.values()) {
                double hdi = populationData.getHDI();
                 if(hdi < 0.35){
                    Object[] row = new Object[5];
                    row[0] = populationData;
                    row[1] = "populationData Data";
                    row[2] = "HDI";
                    row[3] = populationData.getHDI();
                    row[4] = "high";
                    dtm.addRow(row);
                }
            }
        }
    }
    
//    public void populateTest(){
//        DefaultTableModel dtm = (DefaultTableModel) tblDataDisplay.getModel();
//        dtm.setRowCount(0);
//               Object[] row0 = new Object[3];
//               row0[0] = "PM2.5 Concentration:";
//               row0[1] = airData.getId();
//               row0[2] = "Air Quality";
//               dtm.addRow(row0);
//               
//               Object[] row1 = new Object[3];
//               row1[0] = "Co2 Concentration:";
//               row1[1] = airData.getId();
//               row1[2] = "Air Quality";
//               dtm.addRow(row0);
//            
//        
//    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        txtToYear = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        txtFromYear = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblDataDisplay = new javax.swing.JTable();
        jLabel7 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tblDataIWithIssues = new javax.swing.JTable();
        btnAddToPackage = new javax.swing.JButton();
        btnFilter = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        txtToMonth = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        tblDataInUse = new javax.swing.JTable();
        jLabel11 = new javax.swing.JLabel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel3 = new javax.swing.JPanel();
        btnMeanPop = new javax.swing.JButton();
        jScrollPane6 = new javax.swing.JScrollPane();
        tblPopulation = new javax.swing.JTable();
        btnPlotPop = new javax.swing.JButton();
        cmbFactorTypePop = new javax.swing.JComboBox<>();
        jPanel4 = new javax.swing.JPanel();
        btnMeanVeg = new javax.swing.JButton();
        jScrollPane7 = new javax.swing.JScrollPane();
        tblVegetation = new javax.swing.JTable();
        btnPlotVeg = new javax.swing.JButton();
        cmbFactorTypeVeg = new javax.swing.JComboBox<>();
        jPanel5 = new javax.swing.JPanel();
        btnMeanH = new javax.swing.JButton();
        jScrollPane8 = new javax.swing.JScrollPane();
        tblHousing = new javax.swing.JTable();
        btnPlotHousing = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        btnCaculateAir = new javax.swing.JButton();
        jScrollPane9 = new javax.swing.JScrollPane();
        tblAir = new javax.swing.JTable();
        btnPlotAir = new javax.swing.JButton();
        cmbFactorTypeAir = new javax.swing.JComboBox<>();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane10 = new javax.swing.JScrollPane();
        tblWater = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();
        btnCaculateWater = new javax.swing.JButton();
        btnPlotWater = new javax.swing.JButton();
        cmbFactorTypeWater = new javax.swing.JComboBox<>();
        txtFromMonth = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        btnReport = new javax.swing.JButton();
        btnBack = new javax.swing.JButton();

        txtToYear.setText("YYYY");

        jLabel13.setText("From");

        txtFromYear.setText("YYYY");

        tblDataDisplay.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Create Date", "Data Serial Number", "Data Type"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(tblDataDisplay);

        jLabel7.setFont(new java.awt.Font("Lucida Grande", 1, 24)); // NOI18N
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel7.setText("Data Analyzing");

        jLabel5.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        jLabel5.setText("Data Package-Display ");

        tblDataIWithIssues.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Creat Date", "Data Type", "Index Type", "Value", "Severty"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane3.setViewportView(tblDataIWithIssues);

        btnAddToPackage.setText("Add to Data Package -In Use");
        btnAddToPackage.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddToPackageActionPerformed(evt);
            }
        });

        btnFilter.setText("Filter>>");
        btnFilter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFilterActionPerformed(evt);
            }
        });

        jLabel2.setText("Type in the date range to select data:");

        jLabel14.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        jLabel14.setText("Data with Issues");

        txtToMonth.setText("MM");

        jLabel1.setFont(new java.awt.Font("Lucida Grande", 0, 48)); // NOI18N
        jLabel1.setText("↓");

        tblDataInUse.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null}
            },
            new String [] {
                "Create Date", "Data Serial Number", "Data Type"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane4.setViewportView(tblDataInUse);

        jLabel11.setText("To");

        btnMeanPop.setText("Calculate");
        btnMeanPop.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMeanPopActionPerformed(evt);
            }
        });

        tblPopulation.setAutoCreateRowSorter(true);
        tblPopulation.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Factors", "Mean", "Calculate Standard Deviation", "Calculate Increase Rate"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane6.setViewportView(tblPopulation);

        btnPlotPop.setText("Plot Charts");
        btnPlotPop.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPlotPopActionPerformed(evt);
            }
        });

        cmbFactorTypePop.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane6, javax.swing.GroupLayout.DEFAULT_SIZE, 938, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addComponent(cmbFactorTypePop, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnMeanPop)
                        .addGap(101, 101, 101)
                        .addComponent(btnPlotPop)))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnMeanPop)
                    .addComponent(btnPlotPop)
                    .addComponent(cmbFactorTypePop, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(225, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Population", jPanel3);

        btnMeanVeg.setText("Calculate");
        btnMeanVeg.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMeanVegActionPerformed(evt);
            }
        });

        tblVegetation.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null}
            },
            new String [] {
                "Factors", "Mean", "Calculate Standard Deviation", "Calculate Increase Rate"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane7.setViewportView(tblVegetation);

        btnPlotVeg.setText("Plot Charts");
        btnPlotVeg.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPlotVegActionPerformed(evt);
            }
        });

        cmbFactorTypeVeg.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane7, javax.swing.GroupLayout.DEFAULT_SIZE, 936, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addComponent(cmbFactorTypeVeg, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnMeanVeg, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(92, 92, 92)
                        .addComponent(btnPlotVeg)))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnMeanVeg)
                    .addComponent(btnPlotVeg)
                    .addComponent(cmbFactorTypeVeg, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(252, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Vegetation", jPanel4);

        btnMeanH.setText("Calculate");
        btnMeanH.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMeanHActionPerformed(evt);
            }
        });

        tblHousing.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null}
            },
            new String [] {
                "Factors", "Mean", "Calculate Standard Deviation", "Calculate Increase Rate"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane8.setViewportView(tblHousing);

        btnPlotHousing.setText("Plot Charts");
        btnPlotHousing.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPlotHousingActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(jScrollPane8, javax.swing.GroupLayout.DEFAULT_SIZE, 921, Short.MAX_VALUE))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnMeanH, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(48, 48, 48)
                        .addComponent(btnPlotHousing)))
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnMeanH)
                    .addComponent(btnPlotHousing))
                .addContainerGap(250, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Housing", jPanel5);

        btnCaculateAir.setText("Calculate");
        btnCaculateAir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCaculateAirActionPerformed(evt);
            }
        });

        tblAir.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null}
            },
            new String [] {
                "Factors", "Mean", "Calculate Standard Deviation", "Calculate Increase Rate"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane9.setViewportView(tblAir);

        btnPlotAir.setText("Plot Charts");
        btnPlotAir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPlotAirActionPerformed(evt);
            }
        });

        cmbFactorTypeAir.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jScrollPane9, javax.swing.GroupLayout.DEFAULT_SIZE, 936, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                        .addComponent(cmbFactorTypeAir, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnCaculateAir)
                        .addGap(38, 38, 38)
                        .addComponent(btnPlotAir)
                        .addGap(58, 58, 58))))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(54, 54, 54)
                .addComponent(jScrollPane9, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnCaculateAir)
                    .addComponent(btnPlotAir)
                    .addComponent(cmbFactorTypeAir, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(216, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Air", jPanel6);

        tblWater.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null}
            },
            new String [] {
                "Factors", "Mean", "Calculate Standard Deviation", "Calculate Increase Rate"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane10.setViewportView(tblWater);

        btnCaculateWater.setText("Calculate");
        btnCaculateWater.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCaculateWaterActionPerformed(evt);
            }
        });

        btnPlotWater.setText("Plot Charts");
        btnPlotWater.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPlotWaterActionPerformed(evt);
            }
        });

        cmbFactorTypeWater.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane10, javax.swing.GroupLayout.DEFAULT_SIZE, 936, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(cmbFactorTypeWater, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnCaculateWater)
                        .addGap(32, 32, 32)
                        .addComponent(btnPlotWater)))
                .addContainerGap())
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(169, 169, 169)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 625, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(jScrollPane10, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnCaculateWater)
                    .addComponent(btnPlotWater)
                    .addComponent(cmbFactorTypeWater, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(135, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Water", jPanel2);

        txtFromMonth.setText("MM");
        txtFromMonth.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtFromMonthActionPerformed(evt);
            }
        });

        jLabel12.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        jLabel12.setText("Data Package-In Use");

        btnReport.setText("Go To Report>>");
        btnReport.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReportActionPerformed(evt);
            }
        });

        btnBack.setText("<<Back");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(55, 55, 55)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 206, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 365, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addComponent(btnBack)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnReport))
                        .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 971, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(22, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(46, 46, 46)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel13)
                        .addGap(18, 18, 18)
                        .addComponent(txtFromYear, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtFromMonth, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)
                        .addComponent(jLabel11)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtToYear, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtToMonth, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel2))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addContainerGap()
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                    .addGap(41, 41, 41)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addGroup(jPanel1Layout.createSequentialGroup()
                                                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 365, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                    .addComponent(btnFilter))
                                                .addComponent(jLabel5))
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 206, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(jScrollPane3)))
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addGap(41, 41, 41)
                                            .addComponent(btnAddToPackage)
                                            .addGap(0, 679, Short.MAX_VALUE))))
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                    .addGap(187, 187, 187)
                                    .addComponent(jLabel1)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 768, Short.MAX_VALUE)))
                            .addGap(50, 50, 50)))
                    .addContainerGap()))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(212, 212, 212)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtFromYear, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtFromMonth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtToMonth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11)
                    .addComponent(jLabel13)
                    .addComponent(txtToYear, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(190, 190, 190)
                .addComponent(jLabel12)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 441, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnBack)
                    .addComponent(btnReport))
                .addContainerGap(66, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel5)
                        .addComponent(jLabel14, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGap(47, 47, 47)
                            .addComponent(btnFilter)))
                    .addGap(100, 100, 100)
                    .addComponent(btnAddToPackage, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(683, Short.MAX_VALUE)))
        );

        jScrollPane1.setViewportView(jPanel1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 821, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 575, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnAddToPackageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddToPackageActionPerformed
        // TODO add your handling code here:
        String startYear = txtFromYear.getText();
        String endYear = txtToYear.getText();
        String startMonth = txtFromMonth.getText();
        String endMonth = txtToMonth.getText();
        dataPackage = new DataPackage();
        HousingDataBase checkingHousingDataBase = new HousingDataBase();
        AirDataBase checkingAirDataBase = new AirDataBase();
        PopulationDataBase checkingPopulationDataBase = new PopulationDataBase();
        VegetationDataBase checkingVegetationDataBase = new VegetationDataBase();
        WaterDataBase checkingWaterDataBase = new WaterDataBase();
        
        for (int month = Integer.parseInt(startMonth); month <= 12; month++) {
            HousingData checkingHousingData = workRequestCommon.getDataPackage().getHousingDataBase().getInnerHMap(String.valueOf(startYear)).get(String.valueOf(month));
            checkingHousingDataBase.addNewHousingData(checkingHousingData);

            AirData checkingAirData = workRequestCommon.getDataPackage().getAirDataBase().getInnerHMap(String.valueOf(startYear)).get(String.valueOf(month));
            checkingAirDataBase.addNewAirData(checkingAirData);

            PopulationData checkingPopulationData = workRequestCommon.getDataPackage().getPopulationDataBase().getInnerHMap(String.valueOf(startYear)).get(String.valueOf(month));
            checkingPopulationDataBase.addNewPopulationData(checkingPopulationData);

            VegetationData checkingVegetationData = workRequestCommon.getDataPackage().getVegetationDataBase().getInnerHMap(String.valueOf(startYear)).get(String.valueOf(month));
            checkingVegetationDataBase.addNewVegetationData(checkingVegetationData);

            WaterData checkingWaterData = workRequestCommon.getDataPackage().getWaterDataBase().getInnerHMap(String.valueOf(startYear)).get(String.valueOf(month));
            checkingWaterDataBase.addNewWaterData(checkingWaterData);
        }
        for (int year = Integer.parseInt(startYear) + 1; year < Integer.parseInt(endYear); year++) {
            for (HousingData neededHousingData : workRequestCommon.getDataPackage().getHousingDataBase().getInnerHMap(String.valueOf(year)).values()) {
                checkingHousingDataBase.addNewHousingData(neededHousingData);
            }
        }
        for (int year = Integer.parseInt(startYear) + 1; year < Integer.parseInt(endYear); year++) {
            for (AirData checkingAirData : workRequestCommon.getDataPackage().getAirDataBase().getInnerHMap(String.valueOf(year)).values()) {
                checkingAirDataBase.addNewAirData(checkingAirData);
            }
        }

        for (int year = Integer.parseInt(startYear) + 1; year < Integer.parseInt(endYear); year++) {
            for (WaterData checkingWaterData : workRequestCommon.getDataPackage().getWaterDataBase().getInnerHMap(String.valueOf(year)).values()) {
                checkingWaterDataBase.addNewWaterData(checkingWaterData);
            }
        }

        for (int year = Integer.parseInt(startYear) + 1; year < Integer.parseInt(endYear); year++) {
            for (VegetationData checkingVegetationData : workRequestCommon.getDataPackage().getVegetationDataBase().getInnerHMap(String.valueOf(year)).values()) {
                checkingVegetationDataBase.addNewVegetationData(checkingVegetationData);
            }
        }

        for (int year = Integer.parseInt(startYear) + 1; year < Integer.parseInt(endYear); year++) {
            for (PopulationData checkingPopulationData : workRequestCommon.getDataPackage().getPopulationDataBase().getInnerHMap(String.valueOf(year)).values()) {
                checkingPopulationDataBase.addNewPopulationData(checkingPopulationData);
            }
        }
        for (int month = 1; month <= Integer.parseInt(endMonth); month++) {
            HousingData checkingHousingData = workRequestCommon.getDataPackage().getHousingDataBase().getInnerHMap(String.valueOf(endYear)).get(String.valueOf(month));
            checkingHousingDataBase.addNewHousingData(checkingHousingData);

            AirData checkingAirData = workRequestCommon.getDataPackage().getAirDataBase().getInnerHMap(String.valueOf(endYear)).get(String.valueOf(month));
            checkingAirDataBase.addNewAirData(checkingAirData);

            PopulationData checkingPopulationData = workRequestCommon.getDataPackage().getPopulationDataBase().getInnerHMap(String.valueOf(endYear)).get(String.valueOf(month));
            checkingPopulationDataBase.addNewPopulationData(checkingPopulationData);

            VegetationData checkingVegetationData = workRequestCommon.getDataPackage().getVegetationDataBase().getInnerHMap(String.valueOf(endYear)).get(String.valueOf(month));
            checkingVegetationDataBase.addNewVegetationData(checkingVegetationData);

            WaterData checkingWaterData = workRequestCommon.getDataPackage().getWaterDataBase().getInnerHMap(String.valueOf(endYear)).get(String.valueOf(month));
            checkingWaterDataBase.addNewWaterData(checkingWaterData);
            
           
        }
        dataPackage.setAirDataBase(checkingAirDataBase);
        dataPackage.setWaterDataBase(checkingWaterDataBase);
        dataPackage.setVegetationDataBase(checkingVegetationDataBase);
        dataPackage.setPopulationDataBase(checkingPopulationDataBase);
        dataPackage.setHousingDataBase(checkingHousingDataBase);
        populateTblDataInUse(dataPackage);
    }//GEN-LAST:event_btnAddToPackageActionPerformed

    private void txtFromMonthActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtFromMonthActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtFromMonthActionPerformed

    private void btnFilterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFilterActionPerformed
        // TODO add your handling code here:
        
        populateTblDataWithIssues();
    }//GEN-LAST:event_btnFilterActionPerformed

    private void btnMeanPopActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMeanPopActionPerformed
       ArrayList <Double> IList = new ArrayList();
        int iMean=0;
        double iSD=0;
        double iIncreamentalRatio=0;
        for (HashMap<String, PopulationData> hMap : dataPackage.getPopulationDataBase().getPopulationHMap().values()) {
            for (PopulationData populationData : hMap.values()) {
                IList.add((double)populationData.getPopulationNumber());
                BasicMathematicMethods methods = new BasicMathematicMethods();
                iMean = (int)methods.getMean(IList);
                iSD = Math.round((methods.getStdDev(IList))*100.0)/100.0;
                iIncreamentalRatio = Math.round((methods.getIncrementalRatio(IList))*100.0)/100.0;
            }
        }
        
        ArrayList <Double> LifeExceptencyIndexList = new ArrayList();
        double leiMean=0;
        double leiSD=0;
        double leiIncreamentalRatio=0;
        for (HashMap<String, PopulationData> hMap : dataPackage.getPopulationDataBase().getPopulationHMap().values()) {
            for (PopulationData populationData : hMap.values()) {
                LifeExceptencyIndexList.add(populationData.getLifeExceptencyIndex());
                BasicMathematicMethods methods = new BasicMathematicMethods();
                leiMean = Math.round((methods.getMean(LifeExceptencyIndexList))*100.0)/100.0;
                leiSD = Math.round((methods.getStdDev(LifeExceptencyIndexList))*100.0)/100.0;
                leiIncreamentalRatio = Math.round((methods.getIncrementalRatio(LifeExceptencyIndexList))*100.0)/100.0;
            }
        }
        
        ArrayList <Double> MeanYearsOfSchoolingIndexList = new ArrayList();
        double mysiMean=0;
        double mysiSD=0;
        double mysiIncreamentalRatio=0;
        for (HashMap<String, PopulationData> hMap : dataPackage.getPopulationDataBase().getPopulationHMap().values()) {
            for (PopulationData PopulationData : hMap.values()) {
                MeanYearsOfSchoolingIndexList.add(PopulationData.getMeanYearsOfSchoolingIndex());
                BasicMathematicMethods methods = new BasicMathematicMethods();
                mysiMean = Math.round((methods.getMean(MeanYearsOfSchoolingIndexList))*100.0)/100.0;
                mysiSD = Math.round((methods.getStdDev(MeanYearsOfSchoolingIndexList))*100.0)/100.0;
                mysiIncreamentalRatio = Math.round((methods.getIncrementalRatio(MeanYearsOfSchoolingIndexList))*100.0)/100.0;
            }
        }
        
        ArrayList <Double> ExpectedYearsOfSchoolingIndexList = new ArrayList();
        double eysiMean=0;
        double eysiSD=0;
        double eysiIncreamentalRatio=0;
        for (HashMap<String, PopulationData> hMap : dataPackage.getPopulationDataBase().getPopulationHMap().values()) {
            for (PopulationData PopulationData : hMap.values()) {
                ExpectedYearsOfSchoolingIndexList.add(PopulationData.getExpectedYearsOfSchoolingIndex());
                BasicMathematicMethods methods = new BasicMathematicMethods();
                eysiMean = Math.round((methods.getMean(ExpectedYearsOfSchoolingIndexList))*100.0)/100.0;
                eysiSD = Math.round((methods.getStdDev(ExpectedYearsOfSchoolingIndexList))*100.0)/100.0;
                eysiIncreamentalRatio = Math.round((methods.getIncrementalRatio(ExpectedYearsOfSchoolingIndexList))*100.0)/100.0;
            }
        }
        
        ArrayList <Double> IncomeIndexList = new ArrayList();
        double incomeIndexMean=0;
        double incomeIndexSD=0;
        double incomeIndexIncreamentalRatio=0;
        for (HashMap<String, PopulationData> hMap : dataPackage.getPopulationDataBase().getPopulationHMap().values()) {
            for (PopulationData PopulationData : hMap.values()) {
                IncomeIndexList.add(PopulationData.getIncomeIndex());
                BasicMathematicMethods methods = new BasicMathematicMethods();
                incomeIndexMean = Math.round((methods.getMean(IncomeIndexList))*100.0)/100.0;
                incomeIndexSD = Math.round((methods.getStdDev(IncomeIndexList))*100.0)/100.0;
                incomeIndexIncreamentalRatio =Math.round(( methods.getIncrementalRatio(IncomeIndexList))*100.0)/100.0;
            
            }
        }
        
        expectedLifeAchievementScale = leiMean;
        incomeSatisfication = incomeIndexMean;
        eduLevel = mysiMean;
        
        populateTblPopulation(iMean,  iSD,  iIncreamentalRatio,
                                          leiMean,  leiSD,  leiIncreamentalRatio,
                                          mysiMean,  mysiSD,  mysiIncreamentalRatio,
                                          eysiMean,  eysiSD,  eysiIncreamentalRatio,
                                          incomeIndexMean,  incomeIndexSD,  incomeIndexIncreamentalRatio);

    }//GEN-LAST:event_btnMeanPopActionPerformed

    private void btnCaculateAirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCaculateAirActionPerformed

        ArrayList <Double> pmConcentrationList = new ArrayList();
        double pmMean = 0;
        double pmSD = 0;
        double pmIncreamentalRatio = 0;
        for (HashMap<String, AirData> hMap : dataPackage.getAirDataBase().getAirHMap().values()) {
            for (AirData airData : hMap.values()) {
                pmConcentrationList.add(airData.getPmConcentration());
                BasicMathematicMethods methods = new BasicMathematicMethods();
                pmMean = Math.round((methods.getMean(pmConcentrationList))*100.0)/100.0;
                pmSD = Math.round((methods.getStdDev(pmConcentrationList))*100.0)/100.0;
                pmIncreamentalRatio =Math.round(( methods.getIncrementalRatio(pmConcentrationList))*100.0)/100.0;
            }
        }
        
        ArrayList <Double> so2ConcentrationList = new ArrayList();
        double so2Mean = 0;
        double so2SD = 0;
        double so2IncreamentalRatio = 0;
        for (HashMap<String, AirData> hMap : dataPackage.getAirDataBase().getAirHMap().values()) {
            for (AirData airData : hMap.values()) {
                so2ConcentrationList.add(airData.getSo2Concentration());
                BasicMathematicMethods methods = new BasicMathematicMethods();
                so2Mean = Math.round((methods.getMean(so2ConcentrationList))*100.0)/100.0;
                so2SD = Math.round((methods.getStdDev(so2ConcentrationList))*100.0)/100.0;
                so2IncreamentalRatio = Math.round((methods.getIncrementalRatio(so2ConcentrationList))*100.0)/100.0;
            }
        }
        
        ArrayList <Double> coConcentrationList = new ArrayList();
        double coMean = 0;
        double coSD = 0;
        double coIncreamentalRatio = 0;
        for (HashMap<String, AirData> hMap : dataPackage.getAirDataBase().getAirHMap().values()) {
            for (AirData airData : hMap.values()) {
                coConcentrationList.add(airData.getCoConcentration());
                BasicMathematicMethods methods = new BasicMathematicMethods();
                coMean = Math.round((methods.getMean(coConcentrationList))*100.0)/100.0;
                coSD = Math.round((methods.getStdDev(coConcentrationList))*100.0)/100.0;
                coIncreamentalRatio = Math.round((methods.getIncrementalRatio(coConcentrationList))*100.0)/100.0;
            }
        }
        AirData airData = new AirData();
        aqi = Math.max(airData.calculateAqi1(pmMean), Math.max(airData.calculateAqi2(so2Mean), airData.calculateAqi3(coMean)));
        
        
        
        
     
        
        populateTblAir(pmMean,pmSD,pmIncreamentalRatio,so2Mean,so2SD,so2IncreamentalRatio,coMean,coSD,coIncreamentalRatio);

    }//GEN-LAST:event_btnCaculateAirActionPerformed

    private void btnCaculateWaterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCaculateWaterActionPerformed
        ArrayList <Double> bod5List = new ArrayList();
        double bod5Mean=0;
        double bod5SD=0;
        double bod5IncreamentalRatio=0;
        for (HashMap<String, WaterData> hMap : dataPackage.getWaterDataBase().getWaterHMap().values()) {
            for (WaterData waterData : hMap.values()) {
                bod5List.add(waterData.getBod5());
                BasicMathematicMethods methods = new BasicMathematicMethods();
                bod5Mean = Math.round((methods.getMean(bod5List))*100.0)/100.0;
                bod5SD = Math.round((methods.getStdDev(bod5List))*100.0)/100.0;
                bod5IncreamentalRatio = Math.round((methods.getIncrementalRatio(bod5List))*100.0)/100.0;
            }
        }
        
        ArrayList <Double> phList = new ArrayList();
        double phMean=0;
        double phSD=0;
        double phIncreamentalRatio=0;
        for (HashMap<String, WaterData> hMap : dataPackage.getWaterDataBase().getWaterHMap().values()) {
            for (WaterData waterData : hMap.values()) {
                phList.add(waterData.getpH());
                BasicMathematicMethods methods = new BasicMathematicMethods();
                phMean = Math.round((methods.getMean(phList))*100.0)/100.0;
                phSD = Math.round((methods.getStdDev(phList))*100.0)/100.0;
                phIncreamentalRatio = Math.round((methods.getIncrementalRatio(phList))*100.0)/100.0;
            }
        }
        
        ArrayList <Double> turbidityList = new ArrayList();
        double turbidityMean=0;
        double turbiditySD=0;
        double turbidityIncreamentalRatio=0;
        for (HashMap<String, WaterData> hMap : dataPackage.getWaterDataBase().getWaterHMap().values()) {
            for (WaterData waterData : hMap.values()) {
                turbidityList.add(waterData.getTurbidity());
                BasicMathematicMethods methods = new BasicMathematicMethods();
                turbidityMean = Math.round((methods.getMean(turbidityList))*100.0)/100.0;
                turbiditySD = Math.round((methods.getStdDev(turbidityList))*100.0)/100.0;
                turbidityIncreamentalRatio = Math.round((methods.getIncrementalRatio(turbidityList))*100.0)/100.0;
            }
        }
        
        ArrayList <Double> temperatureList = new ArrayList();
        double temperatureMean=0;
        double temperatureSD=0;
        double temperatureIncreamentalRatio=0;
        for (HashMap<String, WaterData> hMap : dataPackage.getWaterDataBase().getWaterHMap().values()) {
            for (WaterData waterData : hMap.values()) {
                temperatureList.add(waterData.getTemperature());
                BasicMathematicMethods methods = new BasicMathematicMethods();
                temperatureMean = Math.round((methods.getMean(temperatureList))*100.0)/100.0;
                temperatureSD =  Math.round((methods.getStdDev(temperatureList))*100.0)/100.0;
                temperatureIncreamentalRatio =  Math.round((methods.getIncrementalRatio(temperatureList))*100.0)/100.0;
            }
        }
        
        ArrayList <Double> ssList = new ArrayList();
        double ssMean=0;
        double ssSD=0;
        double ssIncreamentalRatio=0;
        for (HashMap<String, WaterData> hMap : dataPackage.getWaterDataBase().getWaterHMap().values()) {
            for (WaterData waterData : hMap.values()) {
                ssList.add(waterData.getSuspendedSolids());
                BasicMathematicMethods methods = new BasicMathematicMethods();
                ssMean =  Math.round((methods.getMean(ssList))*100.0)/100.0;
                ssSD =  Math.round((methods.getStdDev(ssList))*100.0)/100.0;
                ssIncreamentalRatio =  Math.round((methods.getIncrementalRatio(ssList))*100.0)/100.0;
            }
        }
        
        ArrayList <Double> doList = new ArrayList();
        double doMean=0;
        double doSD=0;
        double doIncreamentalRatio=0;
        for (HashMap<String, WaterData> hMap : dataPackage.getWaterDataBase().getWaterHMap().values()) {
            for (WaterData waterData : hMap.values()) {
                doList.add(waterData.getDissolvedOxygen());
                BasicMathematicMethods methods = new BasicMathematicMethods();
                doMean = Math.round((methods.getMean(doList))*100.0)/100.0;
                doSD = Math.round((methods.getStdDev(doList))*100.0)/100.0;
                doIncreamentalRatio = Math.round((methods.getIncrementalRatio(doList))*100.0)/100.0;
            }
        }
        bod5 = bod5Mean;
        populateTblWater(bod5Mean, bod5SD, bod5IncreamentalRatio, phMean, phSD, phIncreamentalRatio, turbidityMean, turbiditySD, turbidityIncreamentalRatio, temperatureMean, temperatureSD, temperatureIncreamentalRatio, ssMean, ssSD, ssIncreamentalRatio, doMean, doSD, doIncreamentalRatio);
    }//GEN-LAST:event_btnCaculateWaterActionPerformed

    private void btnMeanVegActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMeanVegActionPerformed
        ArrayList <Double> greenAreaRatioList = new ArrayList();
        double greenRatioMean=0;
        double greenRatioSD=0;
        double greenRatioIncreamentalRatio=0;
        for (HashMap<String, VegetationData> hMap : dataPackage.getVegetationDataBase().getVegetationHMap().values()) {
            for (VegetationData VegetationData : hMap.values()) {
                greenAreaRatioList.add(VegetationData.getGreenRatio());
                BasicMathematicMethods methods = new BasicMathematicMethods();
                greenRatioMean = Math.round((methods.getMean(greenAreaRatioList))*100.0)/100.0;
                greenRatioSD = Math.round((methods.getStdDev(greenAreaRatioList))*100.0)/100.0;
                greenRatioIncreamentalRatio = Math.round((methods.getIncrementalRatio(greenAreaRatioList))*100.0)/100.0;
            }
        }
        
        ArrayList <Double> openSpaceRatioList = new ArrayList();
        double osrMean=0;
        double osrSD=0;
        double osrIncreamentalRatio=0;
        for (HashMap<String, VegetationData> hMap : dataPackage.getVegetationDataBase().getVegetationHMap().values()) {
            for (VegetationData VegetationData : hMap.values()) {
                openSpaceRatioList.add(VegetationData.getOsr());
                BasicMathematicMethods methods = new BasicMathematicMethods();
                osrMean = Math.round((methods.getMean(openSpaceRatioList))*100.0)/100.0;
                osrSD = Math.round((methods.getStdDev(openSpaceRatioList))*100.0)/100.0;
                osrIncreamentalRatio = Math.round((methods.getIncrementalRatio(openSpaceRatioList))*100.0)/100.0;
            }
        }
        
        ArrayList <Double> landscapeSurfaceRatioList = new ArrayList();
        double lsrMean=0;
        double lsrSD=0;
        double lsrIncreamentalRatio=0;
        for (HashMap<String, VegetationData> hMap : dataPackage.getVegetationDataBase().getVegetationHMap().values()) {
            for (VegetationData VegetationData : hMap.values()) {
                landscapeSurfaceRatioList.add(VegetationData.getLsr());
                BasicMathematicMethods methods = new BasicMathematicMethods();
                lsrMean = Math.round((methods.getMean(landscapeSurfaceRatioList))*100.0)/100.0;
                lsrSD = Math.round((methods.getStdDev(landscapeSurfaceRatioList))*100.0)/100.0;
                lsrIncreamentalRatio = Math.round((methods.getIncrementalRatio(landscapeSurfaceRatioList))*100.0)/100.0;
            }
        }
        
        ArrayList <Double> forestAreaList = new ArrayList();
        double forestMean=0;
        double forestSD=0;
        double forestIncreamentalRatio=0;
        for (HashMap<String, VegetationData> hMap : dataPackage.getVegetationDataBase().getVegetationHMap().values()) {
            for (VegetationData VegetationData : hMap.values()) {
                forestAreaList.add(VegetationData.getForestArea());
                BasicMathematicMethods methods = new BasicMathematicMethods();
                forestMean = Math.round((methods.getMean(forestAreaList))*100.0)/100.0;
                forestSD = Math.round((methods.getStdDev(forestAreaList))*100.0)/100.0;
                forestIncreamentalRatio = Math.round((methods.getIncrementalRatio(forestAreaList))*100.0)/100.0;
            }
        }
        vegetationStatus = greenRatioMean;
        
       populateTblVegetation(greenRatioMean,greenRatioSD,greenRatioIncreamentalRatio,
             osrMean,osrSD,osrIncreamentalRatio,
             lsrMean,lsrSD,lsrIncreamentalRatio,
             forestMean,forestSD, forestIncreamentalRatio);
    }//GEN-LAST:event_btnMeanVegActionPerformed

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
        userProcessContainer.remove(this);
        CardLayout layout = (CardLayout) userProcessContainer.getLayout();
        layout.previous(userProcessContainer);// TODO add your handling code here:
    }//GEN-LAST:event_btnBackActionPerformed

    private void btnPlotWaterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPlotWaterActionPerformed
       DefaultCategoryDataset dataSet = new DefaultCategoryDataset();
       JFreeChart chart = null;
       int series = dataPackage.getAirDataBase().getAirHMap().size();
       Set<String> yearSet =  dataPackage.getAirDataBase().getAirHMap().keySet();
       
       String factor = (String) cmbFactorTypeWater.getSelectedItem();
       //pm2.5
       if (factor.equals("BOD5")) {
           for (String year : yearSet) {
               Set<String> monthSet = dataPackage.getWaterDataBase().getWaterHMap().get(year).keySet();
               for (String month : monthSet) {
                   WaterData waterData = dataPackage.getWaterDataBase().getWaterHMap().get(year).get(month);
                   dataSet.addValue(waterData.getBod5(), year, month);
               }
                chart = ChartFactory.createLineChart("BOD5", "Month", "Concentration", dataSet);//need dataset to store calculate result
       }
           }
           else if (factor.equals("PH")) {
           for (String year : yearSet) {
               Set<String> monthSet = dataPackage.getWaterDataBase().getWaterHMap().get(year).keySet();
               for (String month : monthSet) {
                   WaterData waterData = dataPackage.getWaterDataBase().getWaterHMap().get(year).get(month);
                   dataSet.addValue(waterData.getpH(), year, month);
               }
           }
           chart = ChartFactory.createLineChart("PH", "Month", "Concentration", dataSet);//need dataset to store calculate result
       }
       
           else if (factor.equals("Turbidity")) {
           for (String year : yearSet) {
               Set<String> monthSet = dataPackage.getWaterDataBase().getWaterHMap().get(year).keySet();
               for (String month : monthSet) {
                   WaterData waterData = dataPackage.getWaterDataBase().getWaterHMap().get(year).get(month);
                   dataSet.addValue(waterData.getTurbidity(), year, month);
               }
           }
           chart = ChartFactory.createLineChart("Turbidity", "Month", "Concentration", dataSet);//need dataset to store calculate result
       }
       
           else if (factor.equals("Temperature")) {
           for (String year : yearSet) {
               Set<String> monthSet = dataPackage.getWaterDataBase().getWaterHMap().get(year).keySet();
               for (String month : monthSet) {
                   WaterData waterData = dataPackage.getWaterDataBase().getWaterHMap().get(year).get(month);
                   dataSet.addValue(waterData.getTemperature(), year, month);
               }
           }
           chart = ChartFactory.createLineChart("Temperature", "Month", "Concentration", dataSet);//need dataset to store calculate result
       }
           else if (factor.equals("Suspended Solids")) {
           for (String year : yearSet) {
               Set<String> monthSet = dataPackage.getWaterDataBase().getWaterHMap().get(year).keySet();
               for (String month : monthSet) {
                   WaterData waterData = dataPackage.getWaterDataBase().getWaterHMap().get(year).get(month);
                   dataSet.addValue(waterData.getSuspendedSolids(), year, month);
               }
           }
           chart = ChartFactory.createLineChart("Suspended Solids", "Month", "Concentration", dataSet);//need dataset to store calculate result
       }
       
           else if (factor.equals("Dissolved Oxygen")) {
           for (String year : yearSet) {
               Set<String> monthSet = dataPackage.getWaterDataBase().getWaterHMap().get(year).keySet();
               for (String month : monthSet) {
                   WaterData waterData = dataPackage.getWaterDataBase().getWaterHMap().get(year).get(month);
                   dataSet.addValue(waterData.getDissolvedOxygen(), year, month);
               }
           }
           chart = ChartFactory.createLineChart("Dissolved Oxygen", "Month", "Concentration", dataSet);//need dataset to store calculate result
       }
       
        
       chart.setBackgroundPaint(Color.white);
       chart.getTitle().setPaint(Color.BLACK);
       CategoryPlot plot = (CategoryPlot) chart.getPlot();
       plot.setBackgroundPaint(Color.lightGray);
       plot.setRangeGridlinePaint(Color.YELLOW);
       
       NumberAxis rangeAxis = (NumberAxis) plot.getRangeAxis();
       rangeAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
       rangeAxis.setAutoRangeIncludesZero(true);
       
       
       LineAndShapeRenderer renderer = (LineAndShapeRenderer) plot.getRenderer();
//        renderer.setDrawShapes(true);
       
       Random random = new Random();
       
       for (int j = 0; j <= series; j++) {
           float randomValue = random.nextFloat();
           renderer.setSeriesStroke(
                   j, new BasicStroke(
                           2.0f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND,
                           1.0f, new float[]{randomValue, 6.0f}, 0.0f
                   )
           );
//        return chart;
           
       }
            ChartFrame frame = new ChartFrame("Line Chart", chart);
           frame.setVisible(true);
           frame.setSize(450, 300);
       
        
        // TODO add your handling code here:
    }//GEN-LAST:event_btnPlotWaterActionPerformed

    private void btnPlotAirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPlotAirActionPerformed
       DefaultCategoryDataset dataSet = new DefaultCategoryDataset();
       JFreeChart chart = null;
       int series = dataPackage.getAirDataBase().getAirHMap().size();
       Set<String> yearSet =  dataPackage.getAirDataBase().getAirHMap().keySet();
       
       String factor = (String) cmbFactorTypeAir.getSelectedItem();
       //pm2.5
       if (factor.equals("SO2 Concentration")) {
           for (String year : yearSet) {
               Set<String> monthSet = dataPackage.getAirDataBase().getAirHMap().get(year).keySet();
               for (String month : monthSet) {
                   AirData airData = dataPackage.getAirDataBase().getAirHMap().get(year).get(month);
                   dataSet.addValue(airData.getSo2Concentration(), year, month);
               }
           }
           chart = ChartFactory.createLineChart("SO2 Concentration", "Month", "Concentration", dataSet);//need dataset to store calculate result
       }
       
       else if (factor.equals("CO Concentration")) {
           for (String year : yearSet) {
               Set<String> monthSet = dataPackage.getAirDataBase().getAirHMap().get(year).keySet();
               for (String month : monthSet) {
                   AirData airData = dataPackage.getAirDataBase().getAirHMap().get(year).get(month);
                   dataSet.addValue(airData.getCoConcentration(), year, month);
               }
           }
           chart = ChartFactory.createLineChart("CO Concentration", "Month", "Concentration", dataSet);//need dataset to store calculate result
       }
       
       else if (factor.equals("PM2.5")) {
           for (String year : yearSet) {
               Set<String> monthSet = dataPackage.getAirDataBase().getAirHMap().get(year).keySet();
               for (String month : monthSet) {
                   AirData airData = dataPackage.getAirDataBase().getAirHMap().get(year).get(month);
                   dataSet.addValue(airData.getPmConcentration(), year, month);
               }

           }
           chart = ChartFactory.createLineChart("Pm2.5 Concentration", "Month", "Concentration", dataSet);//need dataset to store calculate result

       }

       
       chart.setBackgroundPaint(Color.WHITE);
       chart.getTitle().setPaint(Color.BLACK);
       CategoryPlot plot = (CategoryPlot) chart.getPlot();
       plot.setBackgroundPaint(Color.lightGray);
       plot.setRangeGridlinePaint(Color.YELLOW);
       
       NumberAxis rangeAxis = (NumberAxis) plot.getRangeAxis();
       rangeAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
       rangeAxis.setAutoRangeIncludesZero(true);
       
       
       LineAndShapeRenderer renderer = (LineAndShapeRenderer) plot.getRenderer();
//        renderer.setDrawShapes(true);
       
       Random random = new Random();
       
       for (int j = 0; j <= series; j++) {
           float randomValue = random.nextFloat();
           renderer.setSeriesStroke(
                   j, new BasicStroke(
                           2.0f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND,
                           1.0f, new float[]{randomValue, 6.0f}, 0.0f
                   )
           );
//        return chart;
           ChartFrame frame = new ChartFrame("Line Chart", chart);
           frame.setVisible(true);
           frame.setSize(450, 300);
       }
    }//GEN-LAST:event_btnPlotAirActionPerformed

    private void btnPlotHousingActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPlotHousingActionPerformed
       
       DefaultCategoryDataset dataSet = new DefaultCategoryDataset();
       JFreeChart chart = null;
       int series = dataPackage.getAirDataBase().getAirHMap().size();
       Set<String> yearSet =  dataPackage.getAirDataBase().getAirHMap().keySet();
//       
//       String factor = (String) cmbFactorTypeHousing.getSelectedItem();
//       //pm2.5
//       if (factor.equals("Index Of Housing Price Appreciation")) {
           for (String year : yearSet) {
               Set<String> monthSet = dataPackage.getAirDataBase().getAirHMap().get(year).keySet();
               for (String month : monthSet) {
                   HousingData housingData = dataPackage.getHousingDataBase().getHousingHMap().get(year).get(month);
                   dataSet.addValue(housingData.getIndexOfHousingPriceAppreciation(), year, month);
               }
           }
           chart = ChartFactory.createLineChart("Index Of Housing Price Appreciation", "Month", "Index Of Housing Price Appreciation", dataSet);//need dataset to store calculate result
//       }
       
       
       chart.setBackgroundPaint(Color.white);
       chart.getTitle().setPaint(Color.BLACK);
       CategoryPlot plot = (CategoryPlot) chart.getPlot();
       plot.setBackgroundPaint(Color.lightGray);
       plot.setRangeGridlinePaint(Color.YELLOW);
       
       NumberAxis rangeAxis = (NumberAxis) plot.getRangeAxis();
       rangeAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
       rangeAxis.setAutoRangeIncludesZero(true);
       
       
       LineAndShapeRenderer renderer = (LineAndShapeRenderer) plot.getRenderer();
//        renderer.setDrawShapes(true);
       
       Random random = new Random();
       
       for (int j = 0; j <= series; j++) {
           float randomValue = random.nextFloat();
           renderer.setSeriesStroke(
                   j, new BasicStroke(
                           2.0f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND,
                           1.0f, new float[]{randomValue, 6.0f}, 0.0f
                   )
           );
//        return chart;
           ChartFrame frame = new ChartFrame("Line Chart", chart);
           frame.setVisible(true);
           frame.setSize(450, 300);
       }

        // TODO add your handling code here:
    }//GEN-LAST:event_btnPlotHousingActionPerformed

    private void btnPlotVegActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPlotVegActionPerformed
       DefaultCategoryDataset dataSet = new DefaultCategoryDataset();
       JFreeChart chart = ChartFactory.createLineChart("Green Area Ratio", "Month", "Green Area Ratio", dataSet);
       int series = dataPackage.getAirDataBase().getAirHMap().size();
       Set<String> yearSet =  dataPackage.getAirDataBase().getAirHMap().keySet();
       
       String factor = (String) cmbFactorTypeVeg.getSelectedItem();
       //pm2.5
       if (factor.equals("Green Area Ratio")) {
           for (String year : yearSet) {
               Set<String> monthSet = dataPackage.getVegetationDataBase().getVegetationHMap().get(year).keySet();
               for (String month : monthSet) {
                   VegetationData vegetationData = dataPackage.getVegetationDataBase().getVegetationHMap().get(year).get(month);
                   dataSet.addValue(vegetationData.getGreenRatio(), year, month);
               }
           }
           chart = ChartFactory.createLineChart("Green Area Ratio", "Month", "Green Area Ratio", dataSet);//need dataset to store calculate result
       }
       
       else if (factor.equals("Open space ratio")) {
           for (String year : yearSet) {
               Set<String> monthSet = dataPackage.getVegetationDataBase().getVegetationHMap().get(year).keySet();
               for (String month : monthSet) {
                   VegetationData vegetationData = dataPackage.getVegetationDataBase().getVegetationHMap().get(year).get(month);
                   dataSet.addValue(vegetationData.getOsr(), year, month);
               }
           }
           chart = ChartFactory.createLineChart("Open space ratio", "Month", "Open space ratio", dataSet);//need dataset to store calculate result
       }
       
       else if (factor.equals("Landscape Surface Ratio")) {
           for (String year : yearSet) {
               Set<String> monthSet = dataPackage.getVegetationDataBase().getVegetationHMap().get(year).keySet();
               for (String month : monthSet) {
                   VegetationData vegetationData = dataPackage.getVegetationDataBase().getVegetationHMap().get(year).get(month);
                   dataSet.addValue(vegetationData.getLsr(), year, month);
               }
           }
           chart = ChartFactory.createLineChart("Landscape Surface Ratio", "Month", "Landscape Surface Ratio", dataSet);//need dataset to store calculate result
       }
       
       else if (factor.equals("Forest Area")) {
           for (String year : yearSet) {
               Set<String> monthSet = dataPackage.getVegetationDataBase().getVegetationHMap().get(year).keySet();
               for (String month : monthSet) {
                   VegetationData vegetationData = dataPackage.getVegetationDataBase().getVegetationHMap().get(year).get(month);
                   dataSet.addValue(vegetationData.getForestArea(), year, month);
               }
           }
           chart = ChartFactory.createLineChart("Forest Area", "Month", "Forest Area(Km^2)", dataSet);//need dataset to store calculate result
       }
       
       
       
       
       chart.setBackgroundPaint(Color.BLUE);
       chart.getTitle().setPaint(Color.BLACK);
       CategoryPlot plot = (CategoryPlot) chart.getPlot();
       plot.setBackgroundPaint(Color.lightGray);
       plot.setRangeGridlinePaint(Color.YELLOW);
       
       NumberAxis rangeAxis = (NumberAxis) plot.getRangeAxis();
       rangeAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
       rangeAxis.setAutoRangeIncludesZero(true);
       
       
       LineAndShapeRenderer renderer = (LineAndShapeRenderer) plot.getRenderer();
//        renderer.setDrawShapes(true);
       
       Random random = new Random();
       
       for (int j = 0; j <= series; j++) {
           float randomValue = random.nextFloat();
           renderer.setSeriesStroke(
                   j, new BasicStroke(
                           2.0f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND,
                           1.0f, new float[]{randomValue, 6.0f}, 0.0f
                   )
           );
//        return chart;
           ChartFrame frame = new ChartFrame("Line Chart", chart);
           frame.setVisible(true);
           frame.setSize(450, 300);
       }
       
        // TODO add your handling code here:
    }//GEN-LAST:event_btnPlotVegActionPerformed

    private void btnPlotPopActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPlotPopActionPerformed
DefaultCategoryDataset dataSet = new DefaultCategoryDataset();
      JFreeChart chart = null;
      
      Set<String> yearSet =  dataPackage.getAirDataBase().getAirHMap().keySet();
     
      String factor = (String) cmbFactorTypePop.getSelectedItem();
      //pm2.5
      if (factor.equals("Life Expectancy Index")) {
          for (String year : yearSet) {
              Set<String> monthSet = dataPackage.getAirDataBase().getAirHMap().get(year).keySet();
              for (String month : monthSet) {
                  PopulationData populationData = dataPackage.getPopulationDataBase().getPopulationHMap().get(year).get(month);
                  dataSet.setValue(populationData.getLifeExceptencyIndex(), "Life Expectancy Index", year + "/" + month);
              }
          }
          chart = ChartFactory.createLineChart3D("Life Expectancy Index", "Date", "Value", dataSet);//need dataset to store calculate result
      }
      
      else  if (factor.equals("Mean Years Of Schooling Index")) {
          for (String year : yearSet) {
              Set<String> monthSet = dataPackage.getAirDataBase().getAirHMap().get(year).keySet();
              for (String month : monthSet) {
                  PopulationData populationData = dataPackage.getPopulationDataBase().getPopulationHMap().get(year).get(month);
                  dataSet.setValue(populationData.getMeanYearsOfSchoolingIndex(), "Mean Years Of Schooling Index", year + "/" + month);
              }
          }
          chart = ChartFactory.createLineChart3D("Mean Years Of Schooling Index", "Date", "Value", dataSet);//need dataset to store calculate result
      }
      
      else if (factor.equals("Income Index")) {
          for (String year : yearSet) {
              Set<String> monthSet = dataPackage.getAirDataBase().getAirHMap().get(year).keySet();
              for (String month : monthSet) {
                  PopulationData populationData = dataPackage.getPopulationDataBase().getPopulationHMap().get(year).get(month);
                  dataSet.setValue(populationData.getIncomeIndex(), "Income Index", year + "/" + month);
              }
          }
          chart = ChartFactory.createLineChart3D("Income Index", "Date", "Value", dataSet);//need dataset to store calculate result
      }
      chart.setBackgroundPaint(Color.BLUE);
      chart.getTitle().setPaint(Color.BLACK);
      CategoryPlot plot = (CategoryPlot) chart.getPlot();
      plot.setBackgroundPaint(Color.lightGray);
      plot.setRangeGridlinePaint(Color.YELLOW);
//        return chart;
          ChartFrame frame = new ChartFrame("Bar Chart", chart);
          frame.setVisible(true);
          frame.setSize(450, 300);
        // TODO add your handling code here:
    }//GEN-LAST:event_btnPlotPopActionPerformed

    private void btnMeanHActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMeanHActionPerformed
    
        
        ArrayList <Double> salesVolumeList = new ArrayList();
        int salseVolumeMean = 0;
        double slaesVolumeSD = 0;
        double salesVolumeIR = 0;
        for (HashMap<String, HousingData> hMap : dataPackage.getHousingDataBase().getHousingHMap().values()) {
            for (HousingData HousingData : hMap.values()) {
                salesVolumeList.add((double)HousingData.getSalesVolume());
                BasicMathematicMethods methods = new BasicMathematicMethods();
                salseVolumeMean = (int)methods.getMean(salesVolumeList);
                slaesVolumeSD = Math.round((methods.getStdDev(salesVolumeList))*100.0)/100.0;
                salesVolumeIR = Math.round((methods.getIncrementalRatio(salesVolumeList))*100.0)/100.0;;
                
            }
        }
        
        
        ArrayList <Double> indexOfHousingPriceAppreciationList = new ArrayList();
        double indexOfHousingPriceAppreciationMean = 0.0;
        double indexOfHousingPriceAppreciationSD = 0.0;
        double indexOfHousingPriceAppreciationIR = 0.0;
        for (HashMap<String, HousingData> hMap : dataPackage.getHousingDataBase().getHousingHMap().values()) {
            for (HousingData HousingData : hMap.values()) {
                indexOfHousingPriceAppreciationList.add((double)HousingData.getIndexOfHousingPriceAppreciation());
                BasicMathematicMethods methods = new BasicMathematicMethods();
                indexOfHousingPriceAppreciationMean = Math.round((methods.getMean(indexOfHousingPriceAppreciationList))*100.0)/100.0;
                indexOfHousingPriceAppreciationSD = Math.round((methods.getStdDev(indexOfHousingPriceAppreciationList))*100.0)/100.0;
                indexOfHousingPriceAppreciationIR = Math.round((methods.getIncrementalRatio(indexOfHousingPriceAppreciationList))*100.0)/100.0;
                
            }
        }    
        ArrayList <Double> unitsAuthorizedList = new ArrayList();
        int unitsAuthorizedMean = 0;
        double unitsAuthorizedSD = 0;
        double unitsAuthorizedIR = 0;
        for (HashMap<String, HousingData> hMap : dataPackage.getHousingDataBase().getHousingHMap().values()) {
            for (HousingData HousingData : hMap.values()) {
                unitsAuthorizedList.add((double)HousingData.getUnitsAuthorized());
                BasicMathematicMethods methods = new BasicMathematicMethods();
                unitsAuthorizedMean = (int)methods.getMean(unitsAuthorizedList);
                unitsAuthorizedSD = Math.round((methods.getStdDev(unitsAuthorizedList))*100.0)/100.0;
                unitsAuthorizedIR = Math.round((methods.getIncrementalRatio(unitsAuthorizedList))*100.0)/100.0;
            }
        } 
        housingSatification = indexOfHousingPriceAppreciationMean;
        
        populateTblHousing(
              salseVolumeMean, slaesVolumeSD, salesVolumeIR,
              indexOfHousingPriceAppreciationMean, indexOfHousingPriceAppreciationSD, indexOfHousingPriceAppreciationIR,
              unitsAuthorizedMean, unitsAuthorizedSD, unitsAuthorizedIR);


        // TODO add your handling code here:
    }//GEN-LAST:event_btnMeanHActionPerformed

    private void btnReportActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReportActionPerformed
        // TODO add your handling code here:
        UploadAnalyzingReportJPanel uploadAnalyzingReportJPanel = new UploadAnalyzingReportJPanel(userProcessContainer, 
        aqi,
    bod5,
    vegetationStatus,
    expectedLifeAchievementScale,
    incomeSatisfication,
    eduLevel,
    housingSatification,
    workRequestCommon);
        userProcessContainer.add("uploadAnalyzingReportJPanel", uploadAnalyzingReportJPanel);
        CardLayout layout = (CardLayout) userProcessContainer.getLayout();
        layout.next(userProcessContainer);
    }//GEN-LAST:event_btnReportActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAddToPackage;
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnCaculateAir;
    private javax.swing.JButton btnCaculateWater;
    private javax.swing.JButton btnFilter;
    private javax.swing.JButton btnMeanH;
    private javax.swing.JButton btnMeanPop;
    private javax.swing.JButton btnMeanVeg;
    private javax.swing.JButton btnPlotAir;
    private javax.swing.JButton btnPlotHousing;
    private javax.swing.JButton btnPlotPop;
    private javax.swing.JButton btnPlotVeg;
    private javax.swing.JButton btnPlotWater;
    private javax.swing.JButton btnReport;
    private javax.swing.JComboBox<String> cmbFactorTypeAir;
    private javax.swing.JComboBox<String> cmbFactorTypePop;
    private javax.swing.JComboBox<String> cmbFactorTypeVeg;
    private javax.swing.JComboBox<String> cmbFactorTypeWater;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane10;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable tblAir;
    private javax.swing.JTable tblDataDisplay;
    private javax.swing.JTable tblDataIWithIssues;
    private javax.swing.JTable tblDataInUse;
    private javax.swing.JTable tblHousing;
    private javax.swing.JTable tblPopulation;
    private javax.swing.JTable tblVegetation;
    private javax.swing.JTable tblWater;
    private javax.swing.JTextField txtFromMonth;
    private javax.swing.JTextField txtFromYear;
    private javax.swing.JTextField txtToMonth;
    private javax.swing.JTextField txtToYear;
    // End of variables declaration//GEN-END:variables
}
