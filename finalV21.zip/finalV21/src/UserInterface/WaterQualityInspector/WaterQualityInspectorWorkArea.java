/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UserInterface.WaterQualityInspector;

import Business.Organization.UrbanEnvironmentalOrganization;
import Business.UserAccount.UserAccount;
import java.awt.CardLayout;
import javax.swing.JPanel;

/**
 *
 * @author zhangshu
 */
public class WaterQualityInspectorWorkArea extends javax.swing.JPanel {

    /**
     * Creates new form WaterQualityInspectorWorkArea
     */
    JPanel userProcessContainer;
    private UserAccount userAccount;
    private UrbanEnvironmentalOrganization organization;
    
    public WaterQualityInspectorWorkArea(JPanel userProcessContainer, UserAccount userAccount, UrbanEnvironmentalOrganization organization) {
        initComponents();
        this.userProcessContainer = userProcessContainer;
        this.organization = organization;
        this.userAccount = userAccount;
        System.out.println(organization.getWaterDataBase().getWaterHMap().keySet());
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        btnAddNewData = new javax.swing.JButton();
        dataViewDataBase = new javax.swing.JButton();
        btnManageRequest = new javax.swing.JButton();

        jLabel1.setFont(new java.awt.Font("Lucida Grande", 0, 24)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("My Work Area -Water Quality Inspector Role");

        btnAddNewData.setText("Add New Data");
        btnAddNewData.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddNewDataActionPerformed(evt);
            }
        });

        dataViewDataBase.setText("View Database");
        dataViewDataBase.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dataViewDataBaseActionPerformed(evt);
            }
        });

        btnManageRequest.setText("Manage Request");
        btnManageRequest.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnManageRequestActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(199, 199, 199)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnAddNewData, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(dataViewDataBase, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnManageRequest, javax.swing.GroupLayout.PREFERRED_SIZE, 249, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(208, Short.MAX_VALUE))
            .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(81, 81, 81)
                .addComponent(jLabel1)
                .addGap(74, 74, 74)
                .addComponent(btnAddNewData, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(dataViewDataBase, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnManageRequest, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(120, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnAddNewDataActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddNewDataActionPerformed
        
        AddWaterDataJPanel jpanel = new AddWaterDataJPanel(userProcessContainer, organization.getWaterDataBase());
        userProcessContainer.add("AddWaterDataJPanel", jpanel);
        CardLayout layout = (CardLayout) userProcessContainer.getLayout();
        layout.next(userProcessContainer);// TODO add your handling code here:
    }//GEN-LAST:event_btnAddNewDataActionPerformed

    private void btnManageRequestActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnManageRequestActionPerformed
        UserAccount admin = organization.getUserAccountDirectory().getUserAccountDirectory().get(0);
        ManageWaterRequestJPanel jpanel = new ManageWaterRequestJPanel(userProcessContainer, userAccount.getWorkQueue(), admin.getWorkQueue(), organization, userAccount);
        userProcessContainer.add("ManageWaterRequestJPanel", jpanel);
        CardLayout layout = (CardLayout) userProcessContainer.getLayout();
        layout.next(userProcessContainer);// TODO add your handling code here:
    }//GEN-LAST:event_btnManageRequestActionPerformed

    private void dataViewDataBaseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dataViewDataBaseActionPerformed
        ViewWaterDataBaseJPanel jpanel = new ViewWaterDataBaseJPanel(userProcessContainer, organization.getWaterDataBase());
        userProcessContainer.add("ManageWaterRequestJPanel", jpanel);
        CardLayout layout = (CardLayout) userProcessContainer.getLayout();
        layout.next(userProcessContainer);// TODO add your handling code here:
    }//GEN-LAST:event_dataViewDataBaseActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAddNewData;
    private javax.swing.JButton btnManageRequest;
    private javax.swing.JButton dataViewDataBase;
    private javax.swing.JLabel jLabel1;
    // End of variables declaration//GEN-END:variables
}
