/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UserInterface.AirQualityInspector;


import Business.Data.AirDataBase;
import Business.Organization.UrbanEnvironmentalOrganization;
import Business.UserAccount.UserAccount;
import Business.WorkQueue.WorkQueue;
import Business.WorkQueue.WorkRequest;
import Business.WorkQueue.WorkRequestCommon;
import Business.WorkQueue.WorkRequestReminder;
import java.awt.CardLayout;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author zhangshu
 */
public class ManageAirRequestJPanel extends javax.swing.JPanel {

    /**
     * Creates new form AirQualityInspectorWorkRequestJPanel
     */
    private JPanel userProcessContainer;
    private WorkQueue workQueueOfInspector;
    private WorkQueue workQueueOfAdmin;
    private UrbanEnvironmentalOrganization organization;
    private UserAccount ua;
    private UserAccount adminUserAccount;
    public ManageAirRequestJPanel(JPanel userProcessContainer, WorkQueue workQueueOfInspector, WorkQueue workQueueOfAdmin, UrbanEnvironmentalOrganization organization, UserAccount ua) {
        initComponents();
        this.userProcessContainer = userProcessContainer;
        this.workQueueOfInspector = workQueueOfInspector;
        this.workQueueOfAdmin = workQueueOfAdmin;
        this.organization = organization;
        this.ua = ua;
        populateReceiveTable();
    }

    public void populateReceiveTable(){
        DefaultTableModel dtm=(DefaultTableModel)receiveJTable.getModel();//DefaultTableModel-class
        dtm.setRowCount(0);
        
        for(WorkRequest workRequest : workQueueOfInspector.getWorkRequestList()){
            WorkRequestCommon workRequestCommon = (WorkRequestCommon)workRequest;
            Object[] row=new Object[4];
            row[0]=workRequestCommon;
            row[1]=workRequestCommon.getMessage();
            row[2]=workRequestCommon.getStatus();
            row[3]=workRequestCommon.getRequestDate();
            dtm.addRow(row);
        }
    }

    
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jSeparator1 = new javax.swing.JSeparator();
        jScrollPane2 = new javax.swing.JScrollPane();
        receiveJTable = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();
        btnViewAndProcess = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        btnSend = new javax.swing.JButton();
        btnBack1 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtMessage = new javax.swing.JTextArea();
        jSeparator3 = new javax.swing.JSeparator();
        jLabel4 = new javax.swing.JLabel();
        txtDate = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();

        receiveJTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Request ID", "Date", "Message", "Status"
            }
        ));
        jScrollPane2.setViewportView(receiveJTable);

        jLabel3.setText("Receive Request");

        btnViewAndProcess.setText("View And Process Request");
        btnViewAndProcess.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnViewAndProcessActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("Manage Air Data Request");

        btnSend.setText("Send Text Request");
        btnSend.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSendActionPerformed(evt);
            }
        });

        btnBack1.setText("<<Back");
        btnBack1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBack1ActionPerformed(evt);
            }
        });

        txtMessage.setColumns(20);
        txtMessage.setRows(5);
        jScrollPane1.setViewportView(txtMessage);

        jLabel4.setText("Create Date:");

        jLabel6.setText("Message:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jSeparator1)
            .addComponent(jSeparator3)
            .addGroup(layout.createSequentialGroup()
                .addGap(74, 74, 74)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(btnViewAndProcess)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(79, Short.MAX_VALUE))
            .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(84, 84, 84)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(btnSend)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel6))
                                .addGap(31, 31, 31)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txtDate)
                                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 305, Short.MAX_VALUE)))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(btnBack1)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txtDate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(22, 22, 22)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addComponent(btnSend)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(13, 13, 13)
                .addComponent(jLabel3)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnViewAndProcess)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnBack1)
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnViewAndProcessActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewAndProcessActionPerformed
        AirDataBase airDataBase = organization.getAirDataBase();
        int row= receiveJTable.getSelectedRow();
        if(row<0)
        {
            JOptionPane.showMessageDialog(null, "Please select a row first!", "Warning", JOptionPane.WARNING_MESSAGE);
            return;
        }
        else{
            WorkRequestCommon workRequest = (WorkRequestCommon) receiveJTable.getValueAt(row, 0);
            ViewAndProcessAirRequestJPanel panel= new ViewAndProcessAirRequestJPanel(userProcessContainer, workRequest, airDataBase, ua);
            userProcessContainer.add("ViewAndProcessAirRequestJPanel", panel);
            CardLayout layout= (CardLayout) userProcessContainer.getLayout();
            layout.next(userProcessContainer);
        }
    }//GEN-LAST:event_btnViewAndProcessActionPerformed

    private void btnBack1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBack1ActionPerformed
        userProcessContainer.remove(this);
        CardLayout layout = (CardLayout) userProcessContainer.getLayout();
        layout.previous(userProcessContainer);// TODO add your handling code here:
    }//GEN-LAST:event_btnBack1ActionPerformed

    private void btnSendActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSendActionPerformed
        WorkRequestReminder workRequestReminder = new WorkRequestReminder();
        workRequestReminder.setMessage(txtMessage.getText());
        workRequestReminder.setRequestDate(txtDate.getText());
        workRequestReminder.setStatus("Need confirmation");
        workRequestReminder.setReceiver(organization.getUserAccountDirectory().getUserAccountDirectory().get(0));
        workRequestReminder.setSender(ua);
        JOptionPane.showMessageDialog(null, "Send successfully", "INFO", JOptionPane.WARNING_MESSAGE);
        workQueueOfAdmin.getWorkRequestList().add(workRequestReminder);    
    }//GEN-LAST:event_btnSendActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBack1;
    private javax.swing.JButton btnSend;
    private javax.swing.JButton btnViewAndProcess;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JTable receiveJTable;
    private javax.swing.JTextField txtDate;
    private javax.swing.JTextArea txtMessage;
    // End of variables declaration//GEN-END:variables
}
