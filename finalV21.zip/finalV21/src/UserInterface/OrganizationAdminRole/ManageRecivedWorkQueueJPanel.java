/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UserInterface.OrganizationAdminRole;

import Business.Employee.Employee;
import Business.Organization.Organization;
import Business.WorkQueue.WorkQueue;
import Business.WorkQueue.WorkRequest;
import Business.WorkQueue.WorkRequestCommon;
import Business.WorkQueue.WorkRequestReminder;
import java.awt.CardLayout;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Sc Zhang
 */
public class ManageRecivedWorkQueueJPanel extends javax.swing.JPanel {

    /**
     * Creates new form ManageRecivedWorkQueueJPanel
     */
    
    private JPanel userProcessContainer;
    private Organization organization;
    
    public ManageRecivedWorkQueueJPanel(JPanel userProcessContainer, Organization organization) {
        initComponents();
        this.userProcessContainer = userProcessContainer;
        this.organization = organization;
        populateTable();
        populateReminderTable();
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnViewAndProcess = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        receiveJTable = new javax.swing.JTable();
        btnBack = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tblReminder = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        btnSendRequest = new javax.swing.JButton();

        btnViewAndProcess.setText("View And Process Request");
        btnViewAndProcess.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnViewAndProcessActionPerformed(evt);
            }
        });

        receiveJTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Request ID", "Date", "Message", "Status"
            }
        ));
        jScrollPane2.setViewportView(receiveJTable);

        btnBack.setText("<<Back");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Lucida Grande", 1, 18)); // NOI18N
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("Receive Request");

        tblReminder.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Request ID", "Date", "Message", "Status"
            }
        ));
        jScrollPane3.setViewportView(tblReminder);

        jLabel1.setText("Organization Work Queue: ");

        jLabel2.setText("Work Request Reminder:");

        btnSendRequest.setText("Approve & Go To Send Request");
        btnSendRequest.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSendRequestActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(295, 295, 295)
                        .addComponent(btnBack))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(btnViewAndProcess)
                                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(btnSendRequest, javax.swing.GroupLayout.Alignment.TRAILING))))
                .addContainerGap(31, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel3)
                .addGap(18, 18, 18)
                .addComponent(jLabel1)
                .addGap(9, 9, 9)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnViewAndProcess)
                .addGap(17, 17, 17)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnSendRequest)
                .addGap(30, 30, 30)
                .addComponent(btnBack))
        );
    }// </editor-fold>//GEN-END:initComponents

    public void populateTable(){
        DefaultTableModel model = (DefaultTableModel) receiveJTable.getModel();
        
        model.setRowCount(0);
        System.out.println("Start");
        for (WorkRequest workRequest : organization.getWorkQueue().getWorkRequestList()){
            System.out.println(workRequest);
            WorkRequestCommon workRequestCommon = (WorkRequestCommon)workRequest;
            System.out.println(workRequestCommon.getMessage());
            Object[] row = new Object[4];
            row[0] = workRequestCommon;
            row[1] = workRequestCommon.getRequestDate();
            row[2] = workRequestCommon.getMessage();
            row[3] = workRequestCommon.getStatus();
            model.addRow(row);
        }
    }
    
    public void populateReminderTable(){
        DefaultTableModel model = (DefaultTableModel) tblReminder.getModel();
        
        model.setRowCount(0);
        
        for (WorkRequest workRequest : organization.getUserAccountDirectory().getUserAccountDirectory().get(0).getWorkQueue().getWorkRequestList()){
            WorkRequestReminder workRequestReminder = (WorkRequestReminder)workRequest;
            Object[] row = new Object[4];
            row[0] = workRequestReminder;
            row[1] = workRequestReminder.getRequestDate();
            row[2] = workRequestReminder.getMessage();
            row[3] = workRequestReminder.getStatus();
            model.addRow(row);
        }
    }
    
    private void btnViewAndProcessActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewAndProcessActionPerformed
        int row= receiveJTable.getSelectedRow();
        if(row<0)
        {
            JOptionPane.showMessageDialog(null, "Please select a row first!", "Warning", JOptionPane.WARNING_MESSAGE);
            return;
        }
        else{
            WorkRequest workRequest = (WorkRequest) receiveJTable.getValueAt(row, 0);
           
            ViewAndProcessRequestJPanel viewAndProcessRequestJPanel= new ViewAndProcessRequestJPanel(userProcessContainer, workRequest, organization);
            userProcessContainer.add("viewAndProcessRequestJPanel", viewAndProcessRequestJPanel);
            CardLayout layout= (CardLayout) userProcessContainer.getLayout();
            layout.next(userProcessContainer);
        }
    }//GEN-LAST:event_btnViewAndProcessActionPerformed

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
        userProcessContainer.remove(this);
        CardLayout layout = (CardLayout) userProcessContainer.getLayout();
        layout.previous(userProcessContainer);
    }//GEN-LAST:event_btnBackActionPerformed

    private void btnSendRequestActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSendRequestActionPerformed
        // TODO add your handling code here:
        int row= tblReminder.getSelectedRow();
        if(row<0)
        {
            JOptionPane.showMessageDialog(null, "Please select a row first!", "Warning", JOptionPane.WARNING_MESSAGE);
            return;
        }
        else{
            WorkRequestReminder workRequestReminder = (WorkRequestReminder) tblReminder.getValueAt(row, 0);
            workRequestReminder.setApproved(true);
            workRequestReminder.setStatus("Approved");
            
            userProcessContainer.remove(this);
            CardLayout layout = (CardLayout) userProcessContainer.getLayout();
            layout.previous(userProcessContainer);
        }
    }//GEN-LAST:event_btnSendRequestActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnSendRequest;
    private javax.swing.JButton btnViewAndProcess;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable receiveJTable;
    private javax.swing.JTable tblReminder;
    // End of variables declaration//GEN-END:variables
}
